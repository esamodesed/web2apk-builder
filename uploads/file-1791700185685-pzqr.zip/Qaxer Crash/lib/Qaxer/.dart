class Api {
  static const String api = "http://serverptrerodactyl.smasnug.web.id:2581";
}