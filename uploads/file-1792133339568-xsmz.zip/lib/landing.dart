import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'api_config.dart';
import 'login_page.dart';

// ─── Splash Screen dengan Papan Pengumuman ─────────────────────────────────────
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  
  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _floatCtrl;
  late AnimationController _shakeCtrl;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    
    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    
    _shakeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
    )..repeat(reverse: true, count: 5);
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fadeCtrl.forward();
    });
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _floatCtrl.dispose();
    _shakeCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0A0A),
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.center,
            radius: 1.5,
            colors: [
              const Color(0xFF1A0A2E),
              const Color(0xFF0A0A0A),
              const Color(0xFF000000),
            ],
            stops: const [0, 0.5, 1],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: Center(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Logo di atas
                    _buildLogo(),
                    const SizedBox(height: 24),
                    // Papan kayu dengan teks
                    _buildWoodenBoard(),
                    const SizedBox(height: 24),
                    // Tombol SKIP PAPAN
                    _buildSkipButton(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLogo() {
    return AnimatedBuilder(
      animation: _floatCtrl,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, 5 * _floatCtrl.value),
          child: Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  const Color(0xFFFF1744).withOpacity(0.3),
                  const Color(0xFF2979FF).withOpacity(0.3),
                ],
              ),
              border: Border.all(
                color: const Color(0xFF7C4DFF).withOpacity(0.4),
                width: 3,
              ),
              boxShadow: [
                BoxShadow(
                  color: const Color(0xFFFF1744).withOpacity(0.2),
                  blurRadius: 30,
                  spreadRadius: 5,
                ),
                BoxShadow(
                  color: const Color(0xFF2979FF).withOpacity(0.2),
                  blurRadius: 30,
                  spreadRadius: 5,
                  offset: const Offset(-5, 5),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(60),
              child: Image.asset(
                'assets/images/login.png',
                width: 120,
                height: 120,
                fit: BoxFit.cover,
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildWoodenBoard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: AnimatedBuilder(
        animation: _shakeCtrl,
        builder: (context, child) {
          return Transform.rotate(
            angle: _shakeCtrl.value * 0.01 - 0.005,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                // Efek papan kayu putih dengan tekstur sobek
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    const Color(0xFFF5F5F5),
                    const Color(0xFFE8E8E8),
                    const Color(0xFFF0F0F0),
                    const Color(0xFFE0E0E0),
                  ],
                  stops: const [0, 0.3, 0.7, 1],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: const Color(0xFFC0C0C0),
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.4),
                    blurRadius: 20,
                    spreadRadius: 5,
                    offset: const Offset(0, 10),
                  ),
                  BoxShadow(
                    color: const Color(0xFFFF1744).withOpacity(0.15),
                    blurRadius: 30,
                    spreadRadius: 5,
                  ),
                  BoxShadow(
                    color: const Color(0xFF2979FF).withOpacity(0.15),
                    blurRadius: 30,
                    spreadRadius: 5,
                    offset: const Offset(-5, 5),
                  ),
                ],
              ),
              child: Stack(
                children: [
                  // Efek sobekan di sudut-sudut papan
                  _buildTornCorners(),
                  
                  // Isi teks papan
                  Column(
                    children: [
                      // Garis dekoratif atas
                      Container(
                        width: 60,
                        height: 2,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFFFF1744), Color(0xFF2979FF)],
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      const SizedBox(height: 16),
                      
                      // Teks utama bergaya bajak laut
                      const Text(
                        '⚓ PEMBERITAHUAN ⚓',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFF2C1810),
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Georgia',
                          letterSpacing: 2,
                          shadows: [
                            Shadow(
                              color: Color(0xFFFF6B35),
                              blurRadius: 2,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),
                      
                      Container(
                        width: 100,
                        height: 1,
                        color: const Color(0xFF2C1810).withOpacity(0.3),
                      ),
                      const SizedBox(height: 16),
                      
                      // Teks bajak laut
                      const Text(
                        '🏴‍☠️ APK kiritoXV x Lamborghini 🏴‍☠️',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFF8B0000),
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Georgia',
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 12),
                      
                      const Text(
                        'HANYA UNTUK BERSENANG-SENANG SAJA!',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFF2C1810),
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Georgia',
                        ),
                      ),
                      const SizedBox(height: 12),
                      
                      const Text(
                        '⚠️ PERINGATAN ⚠️',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFFCC0000),
                          fontSize: 14,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Georgia',
                          letterSpacing: 1,
                        ),
                      ),
                      const SizedBox(height: 8),
                      
                      const Text(
                        'UNTUK ORANG-ORANG YANG MENIPU\nDAN LANJUTKAN SAJA...',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Color(0xFF4A2818),
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                          fontFamily: 'Georgia',
                          height: 1.5,
                        ),
                      ),
                      const SizedBox(height: 12),
                      
                      // Garis dekoratif bawah
                      Container(
                        width: 40,
                        height: 2,
                        decoration: BoxDecoration(
                          gradient: const LinearGradient(
                            colors: [Color(0xFF2979FF), Color(0xFFFF1744)],
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTornCorners() {
    return Positioned.fill(
      child: CustomPaint(
        painter: TornCornersPainter(),
      ),
    );
  }

  Widget _buildSkipButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: GestureDetector(
        onTap: () {
          Navigator.pushReplacement(
            context,
            MaterialPageRoute(builder: (_) => const LandingPage()),
          );
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                const Color(0xFFFF1744).withOpacity(0.2),
                const Color(0xFF2979FF).withOpacity(0.2),
              ],
            ),
            borderRadius: BorderRadius.circular(30),
            border: Border.all(
              color: const Color(0xFF7C4DFF).withOpacity(0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFFFF1744).withOpacity(0.15),
                blurRadius: 15,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Icon(
                Icons.skip_next_rounded,
                color: Color(0xFF7C4DFF),
                size: 20,
              ),
              SizedBox(width: 10),
              Text(
                'SKIP PAPAN',
                style: TextStyle(
                  color: Color(0xFFB388FF),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 2,
                ),
              ),
              SizedBox(width: 10),
              Icon(
                Icons.arrow_forward_rounded,
                color: Color(0xFF7C4DFF),
                size: 18,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Custom Painter untuk Efek Sobekan ──────────────────────────────────────
class TornCornersPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = const Color(0xFFD0D0D0)
      ..style = PaintingStyle.fill;

    // Sobekan di sudut kiri atas
    final path1 = Path()
      ..moveTo(0, 0)
      ..lineTo(15, 0)
      ..quadraticBezierTo(8, 8, 0, 15)
      ..close();
    canvas.drawPath(path1, paint);

    // Sobekan di sudut kanan atas
    final path2 = Path()
      ..moveTo(size.width, 0)
      ..lineTo(size.width - 15, 0)
      ..quadraticBezierTo(size.width - 8, 8, size.width, 15)
      ..close();
    canvas.drawPath(path2, paint);

    // Sobekan di sudut kiri bawah
    final path3 = Path()
      ..moveTo(0, size.height)
      ..lineTo(15, size.height)
      ..quadraticBezierTo(8, size.height - 8, 0, size.height - 15)
      ..close();
    canvas.drawPath(path3, paint);

    // Sobekan di sudut kanan bawah
    final path4 = Path()
      ..moveTo(size.width, size.height)
      ..lineTo(size.width - 15, size.height)
      ..quadraticBezierTo(size.width - 8, size.height - 8, size.width, size.height - 15)
      ..close();
    canvas.drawPath(path4, paint);

    // Sobekan tambahan di tepi
    final path5 = Path()
      ..moveTo(20, 0)
      ..lineTo(25, 0)
      ..lineTo(22, 8)
      ..close();
    canvas.drawPath(path5, paint);

    final path6 = Path()
      ..moveTo(size.width - 20, 0)
      ..lineTo(size.width - 25, 0)
      ..lineTo(size.width - 22, 8)
      ..close();
    canvas.drawPath(path6, paint);

    final path7 = Path()
      ..moveTo(20, size.height)
      ..lineTo(25, size.height)
      ..lineTo(22, size.height - 8)
      ..close();
    canvas.drawPath(path7, paint);

    final path8 = Path()
      ..moveTo(size.width - 20, size.height)
      ..lineTo(size.width - 25, size.height)
      ..lineTo(size.width - 22, size.height - 8)
      ..close();
    canvas.drawPath(path8, paint);

    // Garis retak di papan
    final crackPaint = Paint()
      ..color = const Color(0xFFB0B0B0)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    // Retakan horizontal
    canvas.drawLine(
      Offset(40, size.height * 0.4),
      Offset(80, size.height * 0.45),
      crackPaint,
    );
    
    canvas.drawLine(
      Offset(50, size.height * 0.6),
      Offset(100, size.height * 0.65),
      crackPaint,
    );

    // Retakan vertikal
    canvas.drawLine(
      Offset(size.width * 0.3, 30),
      Offset(size.width * 0.35, 60),
      crackPaint,
    );

    canvas.drawLine(
      Offset(size.width * 0.7, 40),
      Offset(size.width * 0.65, 80),
      crackPaint,
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// ─── Palette: Red & Blue Glowing ────────────────────────────────────────────────
class _C {
  // Background tones - hitam dengan aksen merah dan biru
  static const bg         = Color(0xFF0A0A0A);    // Hitam pekat
  static const surface    = Color(0xFF1A0A2E);    // Ungu gelap (campuran merah+biru)
  static const card       = Color(0xFF2D1040);    // Ungu medium gelap
  static const logoBg     = Color(0xFF1A0A2E);    // Ungu gelap
  static const border     = Color(0xFF4A1A6B);    // Ungu tua
  
  // Warna aksen merah
  static const red        = Color(0xFFFF1744);    // Merah terang utama
  static const redDark    = Color(0xFFD50000);    // Merah gelap
  static const redDim     = Color(0xFF4A0E0E);    // Merah sangat gelap
  static const redBorder  = Color(0xFFFF1744);    // Merah terang
  static const redLight   = Color(0xFFFF5252);    // Merah muda
  
  // Warna aksen biru
  static const blue       = Color(0xFF2979FF);    // Biru terang utama
  static const blueDark   = Color(0xFF0D47A1);    // Biru gelap
  static const blueDim    = Color(0xFF0A1A3A);    // Biru sangat gelap
  static const blueLight  = Color(0xFF448AFF);    // Biru muda
  static const blueViolet = Color(0xFF536DFE);    // Biru keunguan
  
  // Warna glowy effect
  static const glowRed    = Color(0xFFFF1744);
  static const glowBlue   = Color(0xFF2979FF);
  static const glowPurple = Color(0xFF7C4DFF);
  
  static const text       = Color(0xFFF3F4F6);    // Putih
  static const textSub    = Color(0xFFB388FF);    // Ungu muda
  static const textDim    = Color(0xFF9575CD);    // Ungu muda gelap

  // Warna sosial media dengan tema merah-biru
  static const socialRed = Color(0xFFFF1744);
  static const socialBlue = Color(0xFF2979FF);
  static const socialGrey = Color(0xFF2D1040);
}

// ─── Landing Page ──────────────────────────────────────────────────────────────
class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage>
    with TickerProviderStateMixin {

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _floatCtrl;
  late AnimationController _glowCtrl;
  late Animation<double> _glowAnim;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOutCubic);
    
    _floatCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    )..repeat(reverse: true);
    
    // Animasi untuk efek glow
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _glowAnim = CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut);
    
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _fadeCtrl.forward();
    });
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _floatCtrl.dispose();
    _glowCtrl.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $uri');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topCenter,
            radius: 1.2,
            colors: [
              _C.surface,
              _C.bg,
              Color(0xFF0A0A0A),
            ],
            stops: [0, 0.5, 1],
          ),
        ),
        child: SafeArea(
          child: FadeTransition(
            opacity: _fadeAnim,
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const SizedBox(height: 24),
                  _buildLogoBox(),
                  const SizedBox(height: 32),
                  _buildBigTitle(),
                  const SizedBox(height: 28),
                  _buildDescCard(),
                  const SizedBox(height: 20),
                  _buildLoginButton(),
                  const SizedBox(height: 14),
                  _buildContactSupportButton(),
                  const SizedBox(height: 28),
                  _buildSocialSection(),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLogoBox() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: AnimatedBuilder(
        animation: _floatCtrl,
        builder: (context, child) {
          return Transform.translate(
            offset: Offset(0, 5 * _floatCtrl.value),
            child: Container(
              width: double.infinity,
              height: 210,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    _C.logoBg.withOpacity(0.9),
                    _C.card.withOpacity(0.8),
                  ],
                ),
                borderRadius: BorderRadius.circular(28),
                border: Border.all(
                  color: _C.glowPurple.withOpacity(0.3),
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _C.glowRed.withOpacity(0.2),
                    blurRadius: 30,
                    spreadRadius: 5,
                    offset: const Offset(0, 10),
                  ),
                  BoxShadow(
                    color: _C.glowBlue.withOpacity(0.2),
                    blurRadius: 30,
                    spreadRadius: 5,
                    offset: const Offset(-5, 5),
                  ),
                ],
              ),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  // Gambar full bingkai
                  ClipRRect(
                    borderRadius: BorderRadius.circular(28),
                    child: Image.asset(
                      'assets/images/login.png',
                      width: double.infinity,
                      height: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  // Overlay gelap merah-biru agar teks lebih terbaca
                  Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(28),
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topCenter,
                        colors: [
                          Colors.black.withOpacity(0.7),
                          _C.red.withOpacity(0.3),
                          _C.blue.withOpacity(0.3),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildBigTitle() {
    return Column(
      children: [
        ShaderMask(
          shaderCallback: (bounds) => const LinearGradient(
            colors: [
              Color(0xFFFF1744),        // Merah terang
              Color(0xFF2979FF),        // Biru terang
              Color(0xFF7C4DFF),        // Ungu
              Color(0xFF448AFF),        // Biru muda
              Color(0xFFFF5252),        // Merah muda
            ],
            stops: [0.0, 0.3, 0.6, 0.8, 1.0],
            begin: Alignment.centerLeft,
            end: Alignment.centerRight,
          ).createShader(bounds),
          child: AnimatedBuilder(
            animation: _glowAnim,
            builder: (context, child) {
              return Text(
                'kiritoXV x Lamborghini',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 44,
                  fontWeight: FontWeight.w900,
                  fontFamily: 'Orbitron',
                  letterSpacing: 4,
                  height: 1.0,
                  shadows: [
                    Shadow(
                      color: _C.glowRed.withOpacity(0.5 + 0.3 * _glowAnim.value),
                      blurRadius: 20,
                    ),
                    Shadow(
                      color: _C.glowBlue.withOpacity(0.5 + 0.3 * (1 - _glowAnim.value)),
                      blurRadius: 20,
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Container(
          width: 180,
          height: 2,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10),
            gradient: const LinearGradient(
              colors: [Color(0xFFFF1744), Color(0xFF2979FF), Color(0xFF7C4DFF), Color(0xFF448AFF)],
            ),
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                _C.red.withOpacity(0.1), 
                _C.blue.withOpacity(0.1),
              ],
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: _C.glowPurple.withOpacity(0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: _C.glowPurple.withOpacity(0.2),
                blurRadius: 15,
                spreadRadius: 2,
              ),
            ],
          ),
          child: const Text(
            'G A C O R   •   T E R U P D A T E   •   S T A B I L',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Color(0xFFB388FF),
              fontSize: 11,
              letterSpacing: 2,
              fontWeight: FontWeight.w600,
              fontFamily: 'Orbitron',
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildDescCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              _C.card.withOpacity(0.7),
              _C.card.withOpacity(0.5),
            ],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: _C.glowPurple.withOpacity(0.3),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: _C.glowRed.withOpacity(0.15),
              blurRadius: 25,
              spreadRadius: 3,
              offset: const Offset(0, 8),
            ),
            BoxShadow(
              color: _C.glowBlue.withOpacity(0.15),
              blurRadius: 25,
              spreadRadius: 3,
              offset: const Offset(-5, 5),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    _C.redDim.withOpacity(0.6), 
                    _C.blueDim.withOpacity(0.6),
                    _C.glowPurple.withOpacity(0.4),
                  ],
                ),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(
                  color: _C.glowPurple.withOpacity(0.5), 
                  width: 2,
                ),
                boxShadow: [
                  BoxShadow(
                    color: _C.glowRed.withOpacity(0.4),
                    blurRadius: 15,
                    spreadRadius: 2,
                  ),
                  BoxShadow(
                    color: _C.glowBlue.withOpacity(0.4),
                    blurRadius: 15,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: const Center(
                child: Icon(
                  Icons.shield_outlined,
                  color: Color(0xFFB388FF),
                  size: 30,
                ),
              ),
            ),
            const SizedBox(height: 20),
            ShaderMask(
              shaderCallback: (bounds) => const LinearGradient(
                colors: [Color(0xFFFF1744), Color(0xFF2979FF), Color(0xFF7C4DFF)],
              ).createShader(bounds),
              child: AnimatedBuilder(
                animation: _glowAnim,
                builder: (context, child) {
                  return Text(
                    'kiritoXV x Lamborghini BUG',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 2,
                      shadows: [
                        Shadow(
                          color: _C.glowPurple.withOpacity(0.4 + 0.3 * _glowAnim.value),
                          blurRadius: 15,
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Aplikasi dengan design elegant dan fitur terbaru.\nPengembangan langsung oleh TEAM kiritoXV x Lamborghini.',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: _C.textSub,
                fontSize: 13,
                height: 1.6,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLoginButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: AnimatedBuilder(
        animation: _glowAnim,
        builder: (context, child) {
          return AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: double.infinity,
            height: 56,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _C.red.withOpacity(0.15),
                  _C.blue.withOpacity(0.15),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: _C.glowPurple.withOpacity(0.5 + 0.3 * _glowAnim.value),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: _C.glowRed.withOpacity(0.3 + 0.2 * _glowAnim.value),
                  blurRadius: 20,
                  spreadRadius: 3,
                ),
                BoxShadow(
                  color: _C.glowBlue.withOpacity(0.3 + 0.2 * (1 - _glowAnim.value)),
                  blurRadius: 20,
                  spreadRadius: 3,
                ),
              ],
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () => Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (_) => LoginPage()),
                ),
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.rocket_launch_rounded, 
                        color: _C.glowPurple, 
                        size: 20,
                      ),
                      const SizedBox(width: 12),
                      ShaderMask(
                        shaderCallback: (bounds) => const LinearGradient(
                          colors: [Color(0xFFFF1744), Color(0xFF2979FF)],
                        ).createShader(bounds),
                        child: const Text(
                          'LOGIN TO kiritoXV x Lamborghini',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildContactSupportButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        height: 56,
        decoration: BoxDecoration(
          color: _C.card.withOpacity(0.5),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: _C.glowPurple.withOpacity(0.3),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: _C.glowPurple.withOpacity(0.15),
              blurRadius: 15,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => _openUrl('https://t.me/LacurKet'),
            borderRadius: BorderRadius.circular(16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.headset_mic_rounded, color: _C.textSub, size: 20),
                const SizedBox(width: 12),
                Text(
                  'CONTACT SUPPORT',
                  style: TextStyle(
                    color: _C.textSub,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSocialSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              _C.card.withOpacity(0.6),
              _C.card.withOpacity(0.4),
            ],
          ),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: _C.glowPurple.withOpacity(0.3),
            width: 2,
          ),
          boxShadow: [
            BoxShadow(
              color: _C.glowRed.withOpacity(0.1),
              blurRadius: 20,
              spreadRadius: 3,
              offset: const Offset(0, 5),
            ),
            BoxShadow(
              color: _C.glowBlue.withOpacity(0.1),
              blurRadius: 20,
              spreadRadius: 3,
              offset: const Offset(-5, 5),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    _C.red.withOpacity(0.1), 
                    _C.blue.withOpacity(0.1),
                  ],
                ),
                borderRadius: BorderRadius.circular(20),
                border: Border.all(
                  color: _C.glowPurple.withOpacity(0.2),
                ),
              ),
              child: Text(
                'HUBUNGI KAMI',
                style: TextStyle(
                  color: _C.textSub,
                  fontSize: 11,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildSocialItem(
                  icon: FontAwesomeIcons.telegram,
                  bgColor: Color(0xFF29B6F6),
                  glowColor: Color(0xFF2979FF),
                  label: 'Telegram',
                  onTap: () => _openUrl('https://t.me/LacurKet'),
                ),
                _buildSocialItem(
                  icon: FontAwesomeIcons.tiktok,
                  bgColor: Color(0xFFFF1744),
                  glowColor: Color(0xFFFF1744),
                  label: 'TikTok',
                  onTap: () => _openUrl('https://tiktok.com/@foryoufiq'),
                ),
                _buildSocialItem(
                  icon: FontAwesomeIcons.instagram,
                  bgColor: Color(0xFF7C4DFF),
                  glowColor: Color(0xFF7C4DFF),
                  label: 'Instagram',
                  onTap: () => _openUrl('https://instagram.com/z4mzzxz'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSocialItem({
    required IconData icon,
    required Color bgColor,
    required Color glowColor,
    required String label,
    required VoidCallback onTap,
  }) {
    return AnimatedBuilder(
      animation: _glowAnim,
      builder: (context, child) {
        return GestureDetector(
          onTap: onTap,
          child: Column(
            children: [
              Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: bgColor.withOpacity(0.15),
                  border: Border.all(
                    color: glowColor.withOpacity(0.5 + 0.3 * _glowAnim.value),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: glowColor.withOpacity(0.3 + 0.2 * _glowAnim.value),
                      blurRadius: 20,
                      spreadRadius: 3,
                    ),
                  ],
                ),
                child: Center(
                  child: FaIcon(icon, color: bgColor, size: 26),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                label,
                style: TextStyle(
                  color: _C.textSub,
                  fontSize: 11,
                  fontWeight: FontWeight.w500,
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}