import 'dart:ui';
import 'dart:convert';
import 'dart:async';
import 'dart:io';
import 'dart:math' as math;
import 'dart:math' show Random;
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';
import 'package:geocoding/geocoding.dart';
import 'package:carousel_slider/carousel_slider.dart' as carousel;
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter/services.dart' show HapticFeedback;

import 'api_config.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'al_quran.dart';
import 'anime_home.dart';
import 'spam_pair.dart';
import 'custom_payload.dart';
import 'bug_group_page.dart';
import 'thanks_to_page.dart';
import 'tes_func_page.dart';
import 'chat.dart';

// ─── WORLD CUP + LAMBORGHINI THEME ──────────────────────────────────────────
const Color kBg      = Color(0xFF0A0A0A);
const Color kCard    = Color(0xFF1A1A1A);
const Color kCardAlt = Color(0xFF1A1A1A);
const Color kBorder  = Color(0xFFE53935);
const Color kRed     = Color(0xFFE53935);
const Color kGold    = Color(0xFFFFD700);
const Color kWhite   = Color(0xFFFFFFFF);
const Color kBlack   = Color(0xFF000000);

// ─── WELCOME ANIMATED SPLASH ──────────────────────────────────────────────────
class WelcomeNoMercyIntro extends StatefulWidget {
  final VoidCallback onFinished;
  const WelcomeNoMercyIntro({super.key, required this.onFinished});

  @override
  State<WelcomeNoMercyIntro> createState() => _WelcomeNoMercyIntroState();
}

class _WelcomeNoMercyIntroState extends State<WelcomeNoMercyIntro>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnim;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );

    _scaleAnim = Tween<double>(begin: 0.5, end: 1.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutBack),
    );

    _fadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _controller,
        curve: const Interval(0.0, 0.6, curve: Curves.easeIn),
      ),
    );

    _controller.forward();

    Timer(const Duration(milliseconds: 3200), () {
      if (mounted) {
        widget.onFinished();
      }
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: RadialGradient(
                colors: [Color(0xFF1A1A1A), Color(0xFF0A0A0A)],
                radius: 1.5,
              ),
            ),
          ),
          Center(
            child: FadeTransition(
              opacity: _fadeAnim,
              child: ScaleTransition(
                scale: _scaleAnim,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(24),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0x441A1A1A),
                        border: Border.all(color: kGold.withOpacity(0.8), width: 3),
                        boxShadow: [
                          BoxShadow(
                            color: kGold.withOpacity(0.5),
                            blurRadius: 30,
                            spreadRadius: 10,
                          ),
                        ],
                      ),
                      child: const Icon(
                        Icons.sports_soccer_rounded,
                        size: 54,
                        color: kGold,
                      ),
                    ),
                    const SizedBox(height: 24),
                    const Text(
                      '🏆 WORLD CUP 2026 🏆',
                      style: TextStyle(
                        color: kGold,
                        fontSize: 18,
                        fontFamily: 'Orbitron',
                        letterSpacing: 4,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [kGold, Color(0xFFFFD700), kRed],
                      ).createShader(bounds),
                      child: const Text(
                        'LAMBORGHINI x WORLD CUP',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 26,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 3,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                      decoration: BoxDecoration(
                        color: kCard,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: kGold.withOpacity(0.5)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.flag_rounded, color: kGold, size: 14),
                          const SizedBox(width: 6),
                          Text(
                            '⚽ kiritoXV x Lamborghini ⚽',
                            style: TextStyle(
                              color: kGold.withOpacity(0.8),
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 1,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── PRAYER TIME SERVICE ──────────────────────────────────────────────────────
class PrayerTimeService {
  static Future<Map<String, dynamic>> fetchPrayerTimes(String city) async {
    final now = DateTime.now();
    final uri = Uri.https('api.aladhan.com', '/v1/timingsByCity', {
      'city': city, 'country': 'ID', 'method': '11',
      'day': '${now.day}', 'month': '${now.month}', 'year': '${now.year}',
    });
    try {
      final res = await http.get(uri).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) return jsonDecode(res.body);
    } catch (_) {}
    return {};
  }
}

// ─── ROLE HELPERS ─────────────────────────────────────────────────────────────
Color _roleColor(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return kGold;
    case 'admin':    return kRed;
    case 'reseller': return const Color(0xFF4CAF50);
    case 'vip':      return const Color(0xFFA78BFA);
    default:         return kRed;
  }
}

IconData _roleIcon(String role) {
  switch (role.toLowerCase()) {
    case 'owner':    return Icons.workspace_premium_rounded;
    case 'admin':    return Icons.admin_panel_settings_rounded;
    case 'reseller': return Icons.storefront_rounded;
    case 'vip':      return Icons.star_rounded;
    default:         return Icons.person_rounded;
  }
}

// ─── ANIMATED DOT ─────────────────────────────────────────────────────────────
class _AnimatedDot extends StatefulWidget {
  final Color color;
  final double size;
  const _AnimatedDot({required this.color, this.size = 6});
  @override
  State<_AnimatedDot> createState() => _AnimatedDotState();
}

class _AnimatedDotState extends State<_AnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  @override
  void initState() {
    super.initState();
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _a,
    child: Container(
      width: widget.size, height: widget.size,
      decoration: BoxDecoration(
        shape: BoxShape.circle, color: widget.color,
        boxShadow: [BoxShadow(color: widget.color.withOpacity(0.8), blurRadius: 8, spreadRadius: 2)],
      ),
    ),
  );
}

// ─── LIVE DOT ─────────────────────────────────────────────────────────────────
class _LiveAnimatedDot extends StatefulWidget {
  final double size;
  const _LiveAnimatedDot({this.size = 8});
  @override
  State<_LiveAnimatedDot> createState() => _LiveAnimatedDotState();
}

class _LiveAnimatedDotState extends State<_LiveAnimatedDot>
    with SingleTickerProviderStateMixin {
  late AnimationController _c;
  late Animation<double> _a;
  late List<Color> _colors;
  int _colorIndex = 0;
  
  @override
  void initState() {
    super.initState();
    _colors = [kRed, kGold, kRed];
    _c = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1200))
      ..repeat(reverse: true);
    _a = Tween<double>(begin: 0.3, end: 1.0)
        .animate(CurvedAnimation(parent: _c, curve: Curves.easeInOut));
        
    Timer.periodic(const Duration(milliseconds: 800), (timer) {
      if (mounted) {
        setState(() {
          _colorIndex = (_colorIndex + 1) % _colors.length;
        });
      }
    });
  }
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FadeTransition(
    opacity: _a,
    child: Container(
      width: widget.size, height: widget.size,
      decoration: BoxDecoration(
        shape: BoxShape.circle, 
        color: _colors[_colorIndex],
        boxShadow: [
          BoxShadow(
            color: _colors[_colorIndex].withOpacity(0.8), 
            blurRadius: 12, 
            spreadRadius: 3
          ),
        ],
      ),
    ),
  );
}

// ─── DASHBOARD PAGE ──────────────────────────────────────────────────────────
class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late String sessionKey, username, password, role, expiredDate;
  late List<Map<String, dynamic>> listBug, listDoos;
  late List<dynamic> newsList;
  
  late AnimationController _navRevealController;
  late Animation<double> _navRevealAnimation;
  bool _isNavVisible = true;
  Timer? _navAutoHideTimer;

  Offset? _pagePointerStart;
  int? _pagePointerStartMs;

  late WebSocketChannel channel;
  String androidId = 'unknown';
  File? _profileImage;
  VideoPlayerController? _menuVideoCtrl;

  int _navIndex   = 0;
  int onlineUsers = 0;
  int activeConns = 0;
  bool _showIntro = true;
  int _carouselCurrentIndex = 0;

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;
  late AnimationController _pulseCtrl;
  late Animation<double> _pulseAnim;

  Timer? _statsTimer;
  late PageController _newsPageCtrl;
  int _newsPageViewKey = 0;
  double _currentNewsPage = 0.0;
  late PageController _qaPageCtrl;
  double _currentQaPage = 0.0;

  bool _locationLoading = false;
  bool _locationGranted = false;
  String _prayerCity = 'Surabaya';
  Map<String, String> _prayerTimes = {};
  String _nextPrayerLabel = '';
  String _nextPrayerTime  = '';
  bool _prayerLoading = true;
  Map<String, dynamic>? _hadith;
  bool _hadithLoading = true;
  int _lastHadithNumber = 0;

  // ─── WORLD CUP DATA ──────────────────────────────────────────────────────
  final List<Map<String, dynamic>> _worldCupMatches = const [
    {'home': 'Brazil', 'away': 'France', 'score': '2 - 1', 'flagHome': '🇧🇷', 'flagAway': '🇫🇷'},
    {'home': 'Argentina', 'away': 'England', 'score': '1 - 1', 'flagHome': '🇦🇷', 'flagAway': '🏴󠁧󠁢󠁥󠁮󠁧󠁿'},
    {'home': 'Portugal', 'away': 'Spain', 'score': '0 - 2', 'flagHome': '🇵🇹', 'flagAway': '🇪🇸'},
    {'home': 'Germany', 'away': 'Italy', 'score': '3 - 0', 'flagHome': '🇩🇪', 'flagAway': '🇮🇹'},
    {'home': 'Netherlands', 'away': 'Belgium', 'score': '2 - 2', 'flagHome': '🇳🇱', 'flagAway': '🇧🇪'},
  ];

  final List<Map<String, dynamic>> _standings = const [
    {'team': 'Brazil', 'flag': '🇧🇷', 'played': 3, 'win': 3, 'draw': 0, 'lose': 0, 'points': 9},
    {'team': 'Argentina', 'flag': '🇦🇷', 'played': 3, 'win': 2, 'draw': 1, 'lose': 0, 'points': 7},
    {'team': 'France', 'flag': '🇫🇷', 'played': 3, 'win': 2, 'draw': 0, 'lose': 1, 'points': 6},
    {'team': 'England', 'flag': '🏴󠁧󠁢󠁥󠁮󠁧󠁿', 'played': 3, 'win': 1, 'draw': 2, 'lose': 0, 'points': 5},
    {'team': 'Portugal', 'flag': '🇵🇹', 'played': 3, 'win': 1, 'draw': 1, 'lose': 1, 'points': 4},
    {'team': 'Spain', 'flag': '🇪🇸', 'played': 3, 'win': 1, 'draw': 1, 'lose': 1, 'points': 4},
    {'team': 'Germany', 'flag': '🇩🇪', 'played': 3, 'win': 1, 'draw': 0, 'lose': 2, 'points': 3},
    {'team': 'Italy', 'flag': '🇮🇹', 'played': 3, 'win': 0, 'draw': 1, 'lose': 2, 'points': 1},
  ];

  @override
  void initState() {
    super.initState();
    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();

    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.85, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));

    _navRevealController = AnimationController(
      duration: const Duration(milliseconds: 420),
      vsync: this,
    );
    _navRevealAnimation = CurvedAnimation(
      parent: _navRevealController,
      curve: Curves.easeOutCubic,
    );
    _navRevealController.forward();

    _newsPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _newsPageCtrl.addListener(() {
      if (mounted) setState(() => _currentNewsPage = _newsPageCtrl.page ?? 0.0);
    });

    _qaPageCtrl = PageController(viewportFraction: 0.88, initialPage: 0);
    _qaPageCtrl.addListener(() {
      if (mounted) setState(() => _currentQaPage = _qaPageCtrl.page ?? 0.0);
    });

    _initAndroidId();
    _loadProfileImage();
    _initMenuVideo();
    _detectLocationAndFetchPrayer(); 
    _fetchRandomHadith();
  }

  @override
  void dispose() {
    _navAutoHideTimer?.cancel();
    _navRevealController.dispose();
    _statsTimer?.cancel();
    channel.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _menuVideoCtrl?.dispose();
    _newsPageCtrl.dispose();
    _qaPageCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  void _initMenuVideo() {
    _menuVideoCtrl = VideoPlayerController.asset('assets/videos/banner.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() {});
        _menuVideoCtrl?.setLooping(true);
        _menuVideoCtrl?.setVolume(1.0);
        _menuVideoCtrl?.play();
      });
  }

  Future<void> _initAndroidId() async {
    final info = await DeviceInfoPlugin().androidInfo;
    androidId = info.id;
    _connectWS();
  }

  void _connectWS() {
    channel = WebSocketChannel.connect(Uri.parse('http://zyroback.pterocloud.my.id:10847'));

    channel.sink.add(jsonEncode({
      'type': 'validate',
      'key': sessionKey,
      'androidId': androidId,
    }));

    channel.stream.listen((event) {
      final data = jsonDecode(event);

      if (data['type'] == 'myInfo' && data['valid'] == true && mounted) {
        channel.sink.add(jsonEncode({'type': 'stats'}));
      }

      if (data['type'] == 'stats' && mounted) {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConns = data['activeConnections'] ?? 0;
        });
      }

      if (data['type'] == 'myInfo' && data['valid'] == false && mounted) {
        _handleInvalidSession(data['reason'] ?? 'Session invalid');
      }

      if (data['type'] == 'forceLogout' && mounted) {
        _handleInvalidSession(data['reason'] ?? 'Logged out');
      }
    }, onError: (_) {
      Future.delayed(const Duration(seconds: 3), () {
        if (mounted) _connectWS();
      });
    });

    _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      try {
        channel.sink.add(jsonEncode({'type': 'stats'}));
      } catch (_) {}
    });
  }

  Future<void> _openUrl(String url) async {
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }

  Future<void> _fetchPrayerTimes() async {
    if (!mounted) return;
    setState(() => _prayerLoading = true);
    final data = await PrayerTimeService.fetchPrayerTimes(_prayerCity);
    if (!mounted) return;
    if (data.isNotEmpty) {
      final timings = data['data']?['timings'] ?? {};
      final Map<String, String> times = {
        'Subuh'  : timings['Fajr']    ?? '--:--',
        'Dzuhur' : timings['Dhuhr']   ?? '--:--',
        'Ashar'  : timings['Asr']     ?? '--:--',
        'Maghrib': timings['Maghrib'] ?? '--:--',
        'Isya'   : timings['Isha']    ?? '--:--',
      };
      final now = TimeOfDay.now();
      String nextLabel = 'Isya';
      String nextTime  = times['Isya'] ?? '--:--';
      for (final entry in times.entries) {
        final parts = entry.value.split(':');
        if (parts.length >= 2) {
          final h = int.tryParse(parts[0]) ?? 0;
          final m = int.tryParse(parts[1]) ?? 0;
          if (h > now.hour || (h == now.hour && m > now.minute)) {
            nextLabel = entry.key;
            nextTime  = entry.value;
            break;
          }
        }
      }
      setState(() {
        _prayerTimes     = times;
        _nextPrayerLabel = nextLabel;
        _nextPrayerTime  = nextTime;
        _prayerLoading   = false;
      });
    } else {
      setState(() => _prayerLoading = false);
    }
  }

  Future<void> _detectLocationAndFetchPrayer() async {
    if (!mounted) return;
    setState(() => _locationLoading = true);

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Surabaya';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
        if (permission == LocationPermission.denied) {
          if (mounted) {
            setState(() {
              _locationLoading = false;
              _prayerCity = 'Surabaya';
            });
            await _fetchPrayerTimes();
          }
          return;
        }
      }

      if (permission == LocationPermission.deniedForever) {
        if (mounted) {
          setState(() {
            _locationLoading = false;
            _prayerCity = 'Surabaya';
          });
          await _fetchPrayerTimes();
        }
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.medium,
      );

      final placemarks = await placemarkFromCoordinates(
        position.latitude,
        position.longitude,
      );

      if (placemarks.isNotEmpty && mounted) {
        final place = placemarks.first;
        final city = place.subAdministrativeArea?.isNotEmpty == true
            ? place.subAdministrativeArea!
            : place.locality?.isNotEmpty == true
                ? place.locality!
                : place.administrativeArea ?? 'Surabaya';

        setState(() {
          _prayerCity     = city;
          _locationGranted = true;
          _locationLoading = false;
        });

        await _fetchPrayerTimes();

        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Row(children: [
                const Icon(Icons.location_on_rounded, color: Colors.white, size: 16),
                const SizedBox(width: 8),
                Text('Lokasi terdeteksi: $city', style: TextStyle(color: Colors.white)),
              ]),
              backgroundColor: kRed,
              behavior: SnackBarBehavior.floating,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              duration: const Duration(seconds: 3),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _locationLoading = false;
          _prayerCity = 'Surabaya';
        });
        await _fetchPrayerTimes();
      }
    }
  }

  Future<void> _fetchRandomHadith() async {
    if (!mounted) return;
    setState(() => _hadithLoading = true);
    try {
      int randomNumber;
      do {
        randomNumber = Random().nextInt(100) + 1;
      } while (randomNumber == _lastHadithNumber);
      _lastHadithNumber = randomNumber;
      final response = await http
          .get(Uri.parse('https://api.hadith.gading.dev/books/muslim/$randomNumber'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200 && mounted) {
        setState(() { _hadith = json.decode(response.body); _hadithLoading = false; });
      } else {
        if (mounted) setState(() => _hadithLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _hadithLoading = false);
    }
  }

  void _showChangeCityDialog() {
    final ctrl = TextEditingController(text: _prayerCity);
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('Ganti Lokasi',
            style: TextStyle(color: Colors.white, fontFamily: 'Orbitron', fontSize: 14)),
        content: TextField(
          controller: ctrl,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            hintText: 'Nama kota (misal: Jakarta)',
            hintStyle: const TextStyle(color: Colors.white54),
            filled: true, fillColor: kBg,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            prefixIcon: const Icon(Icons.location_city_rounded, color: kGold),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal', style: TextStyle(color: Colors.white70))),
          ElevatedButton(
            onPressed: () {
              if (ctrl.text.trim().isNotEmpty) {
                setState(() {
                  _prayerCity = ctrl.text.trim();
                  _locationGranted = false;
                });
                _fetchPrayerTimes();
                Navigator.pop(context);
              }
            },
            style: ElevatedButton.styleFrom(
                backgroundColor: kGold,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            child: const Text('Simpan',
                style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _showHadithFullDialog(String arabic, String indo, String source, String number, String grade) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
        child: Container(
          decoration: BoxDecoration(
            color: kCard, borderRadius: BorderRadius.circular(24),
            border: Border.all(color: kGold.withOpacity(0.5)),
            boxShadow: [
              BoxShadow(color: kGold.withOpacity(0.2), blurRadius: 30, spreadRadius: 5),
              BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20, offset: const Offset(0, 8)),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
                  color: kGold.withOpacity(0.2),
                  border: Border(bottom: BorderSide(color: kGold.withOpacity(0.5))),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(shape: BoxShape.circle, color: kGold.withOpacity(0.3)),
                      child: const Icon(Icons.menu_book_rounded, color: kGold, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('HADITH LENGKAP',
                            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'Orbitron')),
                        Text(grade, style: const TextStyle(color: kGold, fontSize: 11)),
                      ]),
                    ),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Container(
                        width: 34, height: 34,
                        decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withOpacity(0.1)),
                        child: const Icon(Icons.close_rounded, color: Colors.white70, size: 18),
                      ),
                    ),
                  ],
                ),
              ),
              ConstrainedBox(
                constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.62),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  padding: const EdgeInsets.all(18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(18),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(16),
                          color: kBg,
                          border: Border.all(color: kGold.withOpacity(0.3)),
                        ),
                        child: Text(arabic,
                            textAlign: TextAlign.right, textDirection: TextDirection.rtl,
                            style: const TextStyle(color: Colors.white, fontSize: 19, height: 2.2)),
                      ),
                      const SizedBox(height: 14),
                      Row(children: [
                        Container(width: 3, height: 18,
                            decoration: BoxDecoration(borderRadius: BorderRadius.circular(2), color: kGold)),
                        const SizedBox(width: 8),
                        const Text('ARTINYA:', style: TextStyle(color: kGold, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                      ]),
                      const SizedBox(height: 10),
                      Container(
                        width: double.infinity, padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(14),
                          color: kBg,
                          border: Border.all(color: kGold.withOpacity(0.2)),
                        ),
                        child: Text(indo,
                            style: const TextStyle(color: Colors.white70, fontSize: 14, fontStyle: FontStyle.italic, height: 1.8)),
                      ),
                      const SizedBox(height: 16),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: kGold.withOpacity(0.5)),
                          color: kGold.withOpacity(0.1),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.receipt_long_rounded, color: kGold, size: 14),
                          const SizedBox(width: 6),
                          Text('${source.isNotEmpty ? source : "Muslim"} #$number',
                              style: const TextStyle(color: kGold, fontSize: 12, fontWeight: FontWeight.bold)),
                        ]),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => AlertDialog(
        backgroundColor: kCard,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        title: const Text('⚠️ Session Expired', style: TextStyle(color: Colors.white)),
        content: Text(message, style: const TextStyle(color: Colors.white70)),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false),
            child: const Text('OK', style: TextStyle(color: kGold)),
          ),
        ],
      ),
    );
  }

  void _onNavTap(int index) {
    setState(() => _navIndex = index);
    if (index == 0) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_newsPageCtrl.hasClients) {
          setState(() {
            _currentNewsPage = 0.0;
            _newsPageViewKey++;
          });
          _newsPageCtrl.jumpToPage(0);
        }
      });
    }
  }

  void _showNav() {
    _navAutoHideTimer?.cancel();
    if (!_isNavVisible) {
      setState(() => _isNavVisible = true);
      _navRevealController.forward();
      HapticFeedback.mediumImpact();
    }
    _scheduleNavAutoHide();
  }

  void _hideNav() {
    _navAutoHideTimer?.cancel();
    if (!_isNavVisible) return;
    _navRevealController.reverse().then((_) {
      if (mounted) setState(() => _isNavVisible = false);
    });
  }

  void _scheduleNavAutoHide() {
    _navAutoHideTimer?.cancel();
    _navAutoHideTimer = Timer(const Duration(seconds: 4), () {
      _hideNav();
    });
  }

  void _onPagePointerDown(PointerDownEvent event) {
    _pagePointerStart = event.position;
    _pagePointerStartMs = DateTime.now().millisecondsSinceEpoch;
  }

  void _onPagePointerUp(PointerUpEvent event) {
    final start = _pagePointerStart;
    final startMs = _pagePointerStartMs;
    _pagePointerStart = null;
    _pagePointerStartMs = null;
    if (start == null || startMs == null) return;

    final dx = event.position.dx - start.dx;
    final dy = event.position.dy - start.dy;
    final elapsedMs =
        (DateTime.now().millisecondsSinceEpoch - startMs).clamp(1, 1000000);
    final elapsedSec = elapsedMs / 1000.0;

    const double distanceThreshold = 32;
    const double velocityThreshold = 250;

    if (dx.abs() <= dy.abs()) {
      _handleVerticalSwipe(dy, elapsedSec, distanceThreshold, velocityThreshold);
    }
  }

  void _handleVerticalSwipe(
    double distance,
    double elapsedSec,
    double distanceThreshold,
    double velocityThreshold,
  ) {
    final velocity = distance / elapsedSec;
    if (distance.abs() < distanceThreshold || velocity.abs() < velocityThreshold) {
      return;
    }

    if (velocity < 0) {
      if (!_isNavVisible) {
        _showNav();
      }
    } else {
      if (_isNavVisible) {
        _hideNav();
      }
    }
  }

  Widget _buildNavGrabber() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        GestureDetector(
          onTap: _hideNav,
          child: Container(
            width: 38,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),
        ),
      ],
    );
  }

  void _onDrawerNav(int index) {
    Widget page;
    switch (index) {
      case 1: page = SellerPage(keyToken: sessionKey); break;
      case 2: page = AdminPage(sessionKey: sessionKey); break;
      case 3: page = OwnerPage(sessionKey: sessionKey, username: username); break;
      default: return;
    }
    Navigator.pop(context);
    Navigator.push(context, MaterialPageRoute(builder: (_) => page)).then((_) {
      if (mounted) {
        setState(() => _navIndex = 0);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (_newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        });
      }
    });
  }

  Widget _buildCurrentPage() {
    switch (_navIndex) {
      case 0:
        return _buildHomePage();
      case 1:
        return _buildChatMenuPage();
      case 2:
        return BugGroupPage(
          sessionKey: sessionKey,
          role: role,
        );
      case 3:
        return InfoPage(sessionKey: sessionKey);
      case 4:
        return ToolsPage(
          sessionKey: sessionKey, 
          userRole: role, 
          listDoos: listDoos
        );
      default:
        return _buildHomePage();
    }
  }

  // ─── HOME PAGE ──────────────────────────────────────────────────────────
  Widget _buildHomePage() {
    return Container(
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          colors: [Color(0xFF1A1A1A), Color(0xFF0A0A0A)],
          radius: 2,
        ),
      ),
      child: FadeTransition(
        opacity: _fadeAnim,
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildBannerVideo(),
              const SizedBox(height: 14),
              _buildWorldCupHeader(),
              const SizedBox(height: 14),
              _buildWelcomeCard(),
              const SizedBox(height: 14),
              _buildWorldCupMatches(),
              const SizedBox(height: 14),
              _buildStandings(),
              const SizedBox(height: 14),
              _buildSenderAndToolsSection(),
              const SizedBox(height: 14),
              _buildQuickActionsSection(),
              const SizedBox(height: 14),
              _buildLatestUpdates(),
              const SizedBox(height: 14),
              _buildPrayerSection(),
              const SizedBox(height: 14),
              _buildHadithSection(),
              const SizedBox(height: 24),
              Center(
                child: Text('⚽ LAMBORGHINI x WORLD CUP ⚽',
                  style: TextStyle(
                    color: kGold.withOpacity(0.3),
                    fontSize: 13, letterSpacing: 4,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  // ─── WORLD CUP HEADER ──────────────────────────────────────────────────
  Widget _buildWorldCupHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [kRed.withOpacity(0.2), kGold.withOpacity(0.1)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: kGold.withOpacity(0.4), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: kGold.withOpacity(0.2),
              blurRadius: 20,
              spreadRadius: 2,
            ),
          ],
        ),
        child: Row(
          children: [
            const Icon(Icons.sports_soccer_rounded, color: kGold, size: 28),
            const SizedBox(width: 12),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '🏆 WORLD CUP 2026',
                  style: TextStyle(
                    color: kGold,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    letterSpacing: 1.5,
                  ),
                ),
                Text(
                  '⚽ Lamborghini Edition ⚽',
                  style: TextStyle(
                    color: Colors.white60,
                    fontSize: 11,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: kRed.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: kRed.withOpacity(0.5)),
              ),
              child: const Text(
                'LIVE',
                style: TextStyle(
                  color: kRed,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── WELCOME CARD ──────────────────────────────────────────────────────
  Widget _buildWelcomeCard() {
    final now = DateTime.now();
    int accountDaysLeft = 0;
    double accountProgress = 0.0;
    String accountStatus = "ACTIVE";

    try {
      final expired = DateTime.parse(expiredDate);
      final difference = expired.difference(now);
      if (difference.inDays <= 0) {
        accountStatus = "EXPIRED";
        accountDaysLeft = 0;
        accountProgress = 0.0;
      } else {
        accountDaysLeft = difference.inDays;
        final totalDays = 30;
        accountProgress = (accountDaysLeft / totalDays).clamp(0.0, 1.0);
        if (accountDaysLeft <= 3) {
          accountStatus = "CRITICAL";
        } else if (accountDaysLeft <= 7) {
          accountStatus = "WARNING";
        } else {
          accountStatus = "ACTIVE";
        }
      }
    } catch (e) {
      accountStatus = "UNKNOWN";
      accountDaysLeft = 0;
      accountProgress = 0.0;
    }

    Color statusColor;
    IconData statusIcon;
    switch (accountStatus) {
      case "ACTIVE":
        statusColor = kGold;
        statusIcon = Icons.check_circle_rounded;
        break;
      case "WARNING":
        statusColor = kRed;
        statusIcon = Icons.warning_rounded;
        break;
      case "CRITICAL":
        statusColor = kRed;
        statusIcon = Icons.error_rounded;
        break;
      case "EXPIRED":
        statusColor = Colors.white54;
        statusIcon = Icons.cancel_rounded;
        break;
      default:
        statusColor = Colors.white54;
        statusIcon = Icons.help_rounded;
    }

    String formattedExpired = expiredDate;
    try {
      final date = DateTime.parse(expiredDate);
      formattedExpired = "${date.day}/${date.month}/${date.year}";
    } catch (_) {}

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: kGold.withOpacity(0.3), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: kGold.withOpacity(0.1),
              blurRadius: 20,
              spreadRadius: 2,
            ),
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(
                  children: [
                    const Icon(Icons.flag_rounded, color: kGold, size: 20),
                    const SizedBox(width: 8),
                    const Text(
                      "DASHBOARD",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: statusColor.withOpacity(0.5), width: 1),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(statusIcon, color: statusColor, size: 12),
                      const SizedBox(width: 4),
                      Text(
                        accountStatus,
                        style: TextStyle(
                          color: statusColor,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Remaining Time",
                  style: TextStyle(
                    color: Colors.white60,
                    fontSize: 9,
                    fontFamily: 'Orbitron',
                  ),
                ),
                Text(
                  "$accountDaysLeft Days Left",
                  style: TextStyle(
                    color: statusColor,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: accountProgress,
                minHeight: 4,
                backgroundColor: Colors.white.withOpacity(0.1),
                valueColor: AlwaysStoppedAnimation<Color>(statusColor),
              ),
            ),
            const SizedBox(height: 14),
            Row(
              children: [
                _buildWelcomeStatChip(
                  icon: _roleIcon(role),
                  label: "ROLE",
                  value: role.toUpperCase(),
                  color: kGold,
                ),
                const SizedBox(width: 6),
                _buildWelcomeStatChip(
                  icon: Icons.calendar_month_rounded,
                  label: "EXPIRED",
                  value: formattedExpired,
                  color: kRed,
                ),
                const SizedBox(width: 6),
                _buildWelcomeStatChip(
                  icon: Icons.people_alt_rounded,
                  label: "ONLINE",
                  value: "$onlineUsers Users",
                  color: kGold,
                ),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                _buildWelcomeStatChip(
                  icon: Icons.devices_rounded,
                  label: "DEVICE",
                  value: "Android ${androidId.substring(0, 4).toUpperCase()}",
                  color: kRed,
                ),
                const SizedBox(width: 6),
                _buildWelcomeStatChip(
                  icon: Icons.battery_full_rounded,
                  label: "BATTERY",
                  value: "78% Charging",
                  color: kGold,
                ),
                const SizedBox(width: 6),
                _buildWelcomeStatChip(
                  icon: Icons.wifi_rounded,
                  label: "NETWORK",
                  value: "WiFi 85%",
                  color: kRed,
                ),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                _buildWelcomeStatChip(
                  icon: Icons.memory_rounded,
                  label: "RAM",
                  value: "2340MB / 4096MB",
                  color: kGold,
                  showProgress: true,
                  progressValue: 0.57,
                  progressColor: kGold,
                ),
                const SizedBox(width: 6),
                _buildWelcomeStatChip(
                  icon: Icons.storage_rounded,
                  label: "STORAGE",
                  value: "86GB / 128GB",
                  color: kRed,
                  showProgress: true,
                  progressValue: 0.67,
                  progressColor: kRed,
                ),
                const SizedBox(width: 6),
                _buildWelcomeStatChip(
                  icon: Icons.android_rounded,
                  label: "SYSTEM",
                  value: "API 33",
                  color: Colors.white54,
                ),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                _buildWelcomeStatChip(
                  icon: Icons.link_rounded,
                  label: "SESSION",
                  value: sessionKey.substring(0, 8).toUpperCase(),
                  color: kGold,
                ),
                const SizedBox(width: 6),
                _buildWelcomeStatChip(
                  icon: Icons.network_check_rounded,
                  label: "CONN",
                  value: "$activeConns Active",
                  color: kRed,
                ),
                const SizedBox(width: 6),
                _buildWelcomeStatChip(
                  icon: Icons.timer_outlined,
                  label: "TIME",
                  value: _formatClock(DateTime.now()),
                  color: kGold,
                ),
              ],
            ),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerLeft,
              child: ScaleTransition(
                scale: _pulseAnim,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: kGold.withOpacity(0.6)),
                    color: kGold.withOpacity(0.1),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _LiveAnimatedDot(size: 8),
                      const SizedBox(width: 6),
                      const Text(
                        '⚽ LIVE ⚽',
                        style: TextStyle(
                          color: kGold,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWelcomeStatChip({
    required IconData icon,
    required String label,
    required String value,
    required Color color,
    bool showProgress = false,
    double progressValue = 0.0,
    Color? progressColor,
  }) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: color.withOpacity(0.2), width: 0.5),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: 10),
                const SizedBox(width: 4),
                Text(
                  label,
                  style: TextStyle(
                    color: Colors.white54,
                    fontSize: 6.5,
                    fontFamily: 'Orbitron',
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 2),
            Text(
              value,
              style: TextStyle(
                color: Colors.white,
                fontSize: 8.5,
                fontWeight: FontWeight.w600,
                fontFamily: 'Orbitron',
              ),
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
            if (showProgress) ...[
              const SizedBox(height: 3),
              ClipRRect(
                borderRadius: BorderRadius.circular(2),
                child: LinearProgressIndicator(
                  value: progressValue.clamp(0.0, 1.0),
                  minHeight: 2.5,
                  backgroundColor: Colors.white.withOpacity(0.1),
                  valueColor: AlwaysStoppedAnimation<Color>(progressColor ?? color),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  String _formatClock(DateTime dt) {
    return "${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}";
  }

  // ─── WORLD CUP MATCHES ──────────────────────────────────────────────────
  Widget _buildWorldCupMatches() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.sports_soccer_rounded, color: kGold, size: 20),
              const SizedBox(width: 8),
              const Text(
                '⚽ PERTANDINGAN HARI INI',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: kRed.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kRed.withOpacity(0.5)),
                ),
                child: const Text(
                  'LIVE',
                  style: TextStyle(
                    color: kRed,
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          SizedBox(
            height: 130,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              itemCount: _worldCupMatches.length,
              itemBuilder: (ctx, index) {
                final match = _worldCupMatches[index];
                return Container(
                  width: 160,
                  margin: const EdgeInsets.only(right: 10),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: kCard,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: kGold.withOpacity(0.3), width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            children: [
                              Text(match['flagHome'], style: const TextStyle(fontSize: 22)),
                              const SizedBox(height: 2),
                              Text(
                                match['home'],
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Orbitron',
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: kGold.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(color: kGold.withOpacity(0.3)),
                            ),
                            child: Text(
                              match['score'],
                              style: const TextStyle(
                                color: kGold,
                                fontSize: 14,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Column(
                            children: [
                              Text(match['flagAway'], style: const TextStyle(fontSize: 22)),
                              const SizedBox(height: 2),
                              Text(
                                match['away'],
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                  fontFamily: 'Orbitron',
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  // ─── STANDINGS ──────────────────────────────────────────────────────────
  Widget _buildStandings() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.emoji_events_rounded, color: kGold, size: 20),
              const SizedBox(width: 8),
              const Text(
                '🏆 KLASEMEN SEMENTARA',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            decoration: BoxDecoration(
              color: kCard,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: kGold.withOpacity(0.3), width: 1),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Container(
                  constraints: BoxConstraints(
                    minWidth: MediaQuery.of(context).size.width - 28,
                  ),
                  child: DataTable(
                    columnSpacing: 8,
                    horizontalMargin: 8,
                    headingRowColor: WidgetStateProperty.all(
                      kGold.withOpacity(0.15),
                    ),
                    dataRowColor: WidgetStateProperty.all(
                      kCardAlt.withOpacity(0.5),
                    ),
                    dividerThickness: 0,
                    border: TableBorder.all(
                      color: kGold.withOpacity(0.2),
                      width: 0.5,
                    ),
                    columns: const [
                      DataColumn(label: Text('#', style: TextStyle(color: kGold, fontSize: 10, fontWeight: FontWeight.bold))),
                      DataColumn(label: Text('Tim', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold))),
                      DataColumn(label: Text('M', style: TextStyle(color: Colors.white54, fontSize: 9))),
                      DataColumn(label: Text('W', style: TextStyle(color: Colors.white54, fontSize: 9))),
                      DataColumn(label: Text('D', style: TextStyle(color: Colors.white54, fontSize: 9))),
                      DataColumn(label: Text('L', style: TextStyle(color: Colors.white54, fontSize: 9))),
                      DataColumn(label: Text('P', style: TextStyle(color: kGold, fontSize: 10, fontWeight: FontWeight.bold))),
                    ],
                    rows: _standings.asMap().entries.map((entry) {
                      final index = entry.key;
                      final s = entry.value;
                      final isTop = index < 3;
                      return DataRow(
                        color: WidgetStateProperty.all(
                          isTop ? kGold.withOpacity(0.08) : Colors.transparent,
                        ),
                        cells: [
                          DataCell(
                            Container(
                              padding: const EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: isTop ? kGold.withOpacity(0.2) : Colors.transparent,
                              ),
                              child: Text(
                                '${index + 1}',
                                style: TextStyle(
                                  color: isTop ? kGold : Colors.white54,
                                  fontSize: 10,
                                  fontWeight: isTop ? FontWeight.bold : FontWeight.normal,
                                ),
                              ),
                            ),
                          ),
                          DataCell(
                            Row(
                              children: [
                                Text(s['flag'], style: const TextStyle(fontSize: 14)),
                                const SizedBox(width: 4),
                                Text(
                                  s['team'],
                                  style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 11,
                                    fontWeight: isTop ? FontWeight.bold : FontWeight.normal,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          DataCell(Text('${s['played']}', style: const TextStyle(color: Colors.white54, fontSize: 10))),
                          DataCell(Text('${s['win']}', style: TextStyle(color: kGold, fontSize: 10))),
                          DataCell(Text('${s['draw']}', style: const TextStyle(color: Colors.white54, fontSize: 10))),
                          DataCell(Text('${s['lose']}', style: TextStyle(color: kRed, fontSize: 10))),
                          DataCell(
                            Text(
                              '${s['points']}',
                              style: TextStyle(
                                color: isTop ? kGold : Colors.white,
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── BANNER VIDEO ──────────────────────────────────────────────────────
  Widget _buildBannerVideo() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: Container(
          height: 190,
          width: double.infinity,
          decoration: BoxDecoration(
            color: kCard,
            border: Border.all(color: kGold.withOpacity(0.3)),
            boxShadow: [
              BoxShadow(
                color: kGold.withOpacity(0.2),
                blurRadius: 30,
                spreadRadius: 5,
                offset: const Offset(0, 10),
              ),
            ],
          ),
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (_menuVideoCtrl != null && _menuVideoCtrl!.value.isInitialized)
                FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _menuVideoCtrl!.value.size.width,
                    height: _menuVideoCtrl!.value.size.height,
                    child: VideoPlayer(_menuVideoCtrl!),
                  ),
                )
              else
                Container(
                  color: kCard,
                ),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xCC0A0A0A),
                      Colors.transparent,
                      Color(0x880A0A0A),
                    ],
                    begin: Alignment.centerLeft,
                    end: Alignment.centerRight,
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        color: Color(0xCC1A1A1A),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: kGold.withOpacity(0.5),
                          width: 1.5,
                        ),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          _LiveAnimatedDot(size: 8),
                          const SizedBox(width: 6),
                          const Text(
                            '⚽ WORLD CUP 2026 ⚽',
                            style: TextStyle(
                              color: kGold,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    ShaderMask(
                      shaderCallback: (bounds) => const LinearGradient(
                        colors: [kGold, kRed],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ).createShader(bounds),
                      child: const Text(
                        'LAMBORGHINI x WORLD CUP',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                          letterSpacing: 3,
                        ),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '🏆 Platform Bug & Tools Terpercaya 🏆',
                      style: TextStyle(
                        color: Colors.white60,
                        fontSize: 11,
                        letterSpacing: 1,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ─── SENDER AND TOOLS SECTION ─────────────────────────────────────────
  Widget _buildSenderAndToolsSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  _slideRoute(BugSenderPage(
                    sessionKey: sessionKey,
                    username: username,
                    role: role,
                  )),
                );
              },
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: kCard,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: kGold.withOpacity(0.4),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: kGold.withOpacity(0.15),
                      blurRadius: 16,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [kGold, kRed],
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(
                            FontAwesomeIcons.whatsapp,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: kGold.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: kGold.withOpacity(0.5),
                            ),
                          ),
                          child: const Text(
                            "SENDER",
                            style: TextStyle(
                              color: kGold,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      "Sender WhatsApp",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "Kirim pesan & manage sender",
                      style: TextStyle(
                        color: Colors.white60,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  _slideRoute(PublicChatPage(
                    sessionKey: sessionKey,
                    username: username,
                    role: role,
                  )),
                );
              },
              child: Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: kCard,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(
                    color: kGold.withOpacity(0.4),
                    width: 1.5,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: kGold.withOpacity(0.15),
                      blurRadius: 16,
                      spreadRadius: 1,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [kGold, kRed],
                            ),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(
                            Icons.chat_bubble_outline_rounded,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: kGold.withOpacity(0.2),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: kGold.withOpacity(0.5),
                            ),
                          ),
                          child: const Text(
                            "CHAT",
                            style: TextStyle(
                              color: kGold,
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    const Text(
                      "Chat Global",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "Chat dengan semua user",
                      style: TextStyle(
                        color: Colors.white60,
                        fontSize: 11,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── QUICK ACTIONS SECTION ──────────────────────────────────────────────
  Widget _buildQuickActionsSection() {
    final actions = [
      _QuickActionData(
        icon: FontAwesomeIcons.whatsapp,
        bgIcon: FontAwesomeIcons.whatsapp,
        title: 'Manage Sender',
        subtitle: 'Manage your active sender',
        gradient: [kRed, kGold],
        onTap: () => Navigator.push(
          context,
          _slideRoute(BugSenderPage(sessionKey: sessionKey, username: username, role: role)),
        ).then((_) {
          if (mounted && _newsPageCtrl.hasClients) {
            setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
            _newsPageCtrl.jumpToPage(0);
          }
        }),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.telegram,
        bgIcon: FontAwesomeIcons.telegram,
        title: 'Join Channel',
        subtitle: 'Info Channel',
        gradient: [kGold, kRed],
        onTap: () => _openUrl('https://t.me/aboutszamz'),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.bookQuran,
        bgIcon: FontAwesomeIcons.bookQuran,
        title: 'Al Quran',
        subtitle: 'Baca Al-Quran',
        gradient: [kRed, kGold],
        onTap: () => Navigator.push(context, _slideRoute(AlQuranPage())),
      ),
      _QuickActionData(
        icon: FontAwesomeIcons.tv,
        bgIcon: FontAwesomeIcons.tv,
        title: 'Anime',
        subtitle: 'Discover & Watch Anime',
        gradient: [kGold, kRed],
        onTap: () => Navigator.push(context, _slideRoute(HomeAnimePage())),
      ),
    ];

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Container(
                width: 44, height: 44,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: kCard,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kGold.withOpacity(0.4)),
                ),
                child: const Icon(Icons.bolt_rounded, color: kGold, size: 22),
              ),
              const SizedBox(width: 12),
              const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('QUICK ACTIONS',
                      style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15,
                        fontFamily: 'Orbitron', letterSpacing: 1)),
                  Text('Fitur Cepat Akses',
                      style: TextStyle(color: Colors.white60, fontSize: 12)),
                ],
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: kCard,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: kGold.withOpacity(0.4)),
                ),
                child: Row(children: [
                  Container(
                      width: 7, height: 7,
                      decoration: const BoxDecoration(shape: BoxShape.circle, color: kGold)),
                  const SizedBox(width: 5),
                  const Text('⚽ WORLD CUP ⚽',
                      style: TextStyle(color: kGold, fontSize: 11, fontWeight: FontWeight.bold)),
                ]),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 180,
          child: PageView.builder(
            controller: _qaPageCtrl,
            itemCount: actions.length,
            onPageChanged: (index) {
              if (mounted) setState(() => _currentQaPage = index.toDouble());
            },
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: _buildAnimatedQuickActionCard(
                  action: actions[index],
                  index: index,
                  currentPage: _currentQaPage,
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 12),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(actions.length, (index) {
            final bool isActive = _currentQaPage.round() == index;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              margin: const EdgeInsets.symmetric(horizontal: 4),
              width: isActive ? 24 : 8,
              height: 8,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                color: isActive ? kGold : Colors.white.withOpacity(0.25),
              ),
            );
          }),
        ),
      ],
    );
  }

  Widget _buildAnimatedQuickActionCard({
    required _QuickActionData action,
    required int index,
    required double currentPage,
  }) {
    bool _pressed = false;
    
    final double distance = (index - currentPage).abs();
    final double targetScale = distance <= 0.01 ? 1.0 : 0.85;
    final double targetOpacity = distance <= 0.01 ? 1.0 : 0.6;
    final Color borderColor = distance <= 0.01 
        ? Colors.white.withOpacity(0.2) 
        : Colors.transparent;
    final double shadowBlur = distance <= 0.01 ? 25 : 10;
    final double shadowSpread = distance <= 0.01 ? 4 : 1;

    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: targetScale, end: targetScale),
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeInOutCubic,
      builder: (context, scaleValue, child) {
        return TweenAnimationBuilder<double>(
          tween: Tween<double>(begin: targetOpacity, end: targetOpacity),
          duration: const Duration(milliseconds: 350),
          curve: Curves.easeInOutCubic,
          builder: (context, opacityValue, child) {
            return Transform.scale(
              scale: scaleValue,
              child: Opacity(
                opacity: opacityValue,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 350),
                  curve: Curves.easeInOutCubic,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(22),
                    border: Border.all(
                      color: borderColor,
                      width: 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: action.gradient.first.withOpacity(
                          distance <= 0.01 ? 0.5 : 0.2
                        ),
                        blurRadius: shadowBlur,
                        spreadRadius: shadowSpread,
                        offset: const Offset(0, 8),
                      ),
                      if (distance <= 0.01)
                        BoxShadow(
                          color: Colors.white.withOpacity(0.05),
                          blurRadius: 30,
                          spreadRadius: 1,
                          offset: const Offset(0, 0),
                        ),
                    ],
                  ),
                  child: StatefulBuilder(
                    builder: (context, setState) {
                      return GestureDetector(
                        onTapDown: (_) => setState(() => _pressed = true),
                        onTapUp: (_) {
                          setState(() => _pressed = false);
                          action.onTap();
                        },
                        onTapCancel: () => setState(() => _pressed = false),
                        child: AnimatedScale(
                          scale: _pressed ? 0.92 : 1.0,
                          duration: const Duration(milliseconds: 150),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(22),
                              gradient: LinearGradient(
                                colors: action.gradient,
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                            ),
                            child: Stack(
                              children: [
                                Positioned(
                                  right: -12,
                                  bottom: -12,
                                  child: AnimatedOpacity(
                                    duration: const Duration(milliseconds: 350),
                                    opacity: distance <= 0.01 ? 0.12 : 0.06,
                                    child: Icon(
                                      action.bgIcon,
                                      color: Colors.white,
                                      size: 110,
                                    ),
                                  ),
                                ),
                                if (distance <= 0.01)
                                  Positioned(
                                    top: -20,
                                    right: -20,
                                    child: Container(
                                      width: 80,
                                      height: 80,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        gradient: RadialGradient(
                                          colors: [
                                            action.gradient.first.withOpacity(0.3),
                                            Colors.transparent,
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                Padding(
                                  padding: const EdgeInsets.all(22),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      AnimatedContainer(
                                        duration: const Duration(milliseconds: 350),
                                        width: distance <= 0.01 ? 56 : 50,
                                        height: distance <= 0.01 ? 56 : 50,
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          color: Colors.white.withOpacity(
                                            distance <= 0.01 ? 0.25 : 0.15
                                          ),
                                          border: Border.all(
                                            color: Colors.white.withOpacity(
                                              distance <= 0.01 ? 0.3 : 0.1
                                            ),
                                            width: distance <= 0.01 ? 2 : 1,
                                          ),
                                        ),
                                        child: Icon(
                                          action.icon,
                                          color: Colors.white,
                                          size: distance <= 0.01 ? 28 : 24,
                                        ),
                                      ),
                                      const Spacer(),
                                      Align(
                                        alignment: Alignment.topRight,
                                        child: AnimatedContainer(
                                          duration: const Duration(milliseconds: 350),
                                          padding: const EdgeInsets.symmetric(
                                            horizontal: 14,
                                            vertical: 6,
                                          ),
                                          decoration: BoxDecoration(
                                            borderRadius: BorderRadius.circular(20),
                                            color: Colors.white.withOpacity(
                                              distance <= 0.01 ? 0.25 : 0.15
                                            ),
                                            border: Border.all(
                                              color: Colors.white.withOpacity(
                                                distance <= 0.01 ? 0.3 : 0.1
                                              ),
                                            ),
                                          ),
                                          child: Text(
                                            distance <= 0.01 ? 'ACTIVE →' : 'Tap →',
                                            style: TextStyle(
                                              color: Colors.white,
                                              fontSize: distance <= 0.01 ? 12 : 11,
                                              fontWeight: FontWeight.bold,
                                              letterSpacing: distance <= 0.01 ? 1 : 0,
                                            ),
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 8),
                                      AnimatedDefaultTextStyle(
                                        duration: const Duration(milliseconds: 350),
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                          fontSize: distance <= 0.01 ? 19 : 17,
                                          fontFamily: 'Orbitron',
                                          letterSpacing: distance <= 0.01 ? 1 : 0,
                                        ),
                                        child: Text(action.title),
                                      ),
                                      const SizedBox(height: 4),
                                      AnimatedDefaultTextStyle(
                                        duration: const Duration(milliseconds: 350),
                                        style: TextStyle(
                                          color: Colors.white.withOpacity(
                                            distance <= 0.01 ? 0.9 : 0.7
                                          ),
                                          fontSize: distance <= 0.01 ? 13 : 12,
                                        ),
                                        child: Text(action.subtitle),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ─── LATEST UPDATES ────────────────────────────────────────────────────
  Widget _buildLatestUpdates() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: kCard,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: kGold.withOpacity(0.3),
                      blurRadius: 12,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.dashboard_customize_rounded,
                  color: kGold,
                  size: 18,
                ),
              ),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '📰 LATEST NEWS',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1.5,
                    ),
                  ),
                  Text(
                    '⚽ World Cup 2026 Update',
                    style: TextStyle(
                      color: Colors.white60,
                      fontSize: 10,
                    ),
                  ),
                ],
              ),
              const Spacer(),
              if (newsList.isNotEmpty)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    color: kCard,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: kGold.withOpacity(0.4),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _AnimatedDot(color: kGold, size: 5),
                      const SizedBox(width: 5),
                      Text(
                        '${newsList.length} New',
                        style: const TextStyle(
                          color: kGold,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (newsList.isNotEmpty)
          SizedBox(
            height: 220,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 14),
              itemCount: newsList.length,
              itemBuilder: (ctx, i) => _buildNewsCardModern(newsList[i]),
            ),
          ),
        if (newsList.isEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Container(
              height: 100,
              decoration: BoxDecoration(
                color: kCard,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: kGold.withOpacity(0.2)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 15,
                  ),
                ],
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.inbox_rounded,
                    color: Colors.white.withOpacity(0.08),
                    size: 32,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Tidak ada update',
                    style: TextStyle(
                      color: Colors.white.withOpacity(0.3),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildNewsCardModern(dynamic item) {
    final imgUrl = item['image']?.toString() ?? '';
    final title = item['title']?.toString() ?? 'No Title';
    final date = item['date']?.toString() ?? item['created_at']?.toString() ?? '';
    final description = item['description']?.toString() ?? '';
    final cardWidth = (MediaQuery.of(context).size.width / 2) - 22;

    return Container(
      width: cardWidth,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        color: kCard,
        border: Border.all(
          color: kGold.withOpacity(0.3),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.3),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: kGold.withOpacity(0.05),
            blurRadius: 30,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(18)),
            child: Stack(
              children: [
                Container(
                  height: 110,
                  width: double.infinity,
                  color: kCard,
                  child: imgUrl.isNotEmpty
                      ? Image.network(
                          imgUrl,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) => Container(
                            color: kCard,
                            child: Center(
                              child: Icon(
                                Icons.image_not_supported,
                                color: Colors.white.withOpacity(0.15),
                                size: 32,
                              ),
                            ),
                          ),
                        )
                      : Container(
                          color: kCard,
                          child: Center(
                            child: Icon(
                              Icons.article_rounded,
                              color: Colors.white.withOpacity(0.1),
                              size: 32,
                            ),
                          ),
                        ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [kGold, kRed],
                      ),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: [
                        BoxShadow(
                          color: kGold.withOpacity(0.5),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: const Text(
                      '⚽ WC',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 8,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    height: 1.3,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                if (description.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  Text(
                    description,
                    style: TextStyle(
                      color: Colors.white60,
                      fontSize: 10,
                      height: 1.3,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
                const Spacer(),
                const SizedBox(height: 6),
                Row(
                  children: [
                    Icon(
                      Icons.access_time_rounded,
                      color: Colors.white.withOpacity(0.25),
                      size: 10,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      date.isNotEmpty
                          ? (date.length > 10 ? date.substring(0, 10) : date)
                          : 'Baru saja',
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.25),
                        fontSize: 9,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.all(3),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: kGold.withOpacity(0.1),
                      ),
                      child: Icon(
                        Icons.arrow_forward_ios_rounded,
                        color: kGold.withOpacity(0.4),
                        size: 9,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── PRAYER SECTION ────────────────────────────────────────────────────
  Widget _buildPrayerSection() {
    final prayerColors = [
      kRed, kGold, kRed, kGold, kRed,
    ];
    final prayerIcons = [
      Icons.nights_stay_rounded,
      Icons.wb_sunny_rounded,
      Icons.cloud_rounded,
      Icons.wb_twilight_rounded,
      Icons.nightlight_round,
    ];
    final prayerKeys = ['Subuh', 'Dzuhur', 'Ashar', 'Maghrib', 'Isya'];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: kGold.withOpacity(0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 25,
              offset: const Offset(0, 10),
            ),
            BoxShadow(
              color: kGold.withOpacity(0.05),
              blurRadius: 30,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        kGold.withOpacity(0.2),
                        kGold.withOpacity(0.08),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: kGold.withOpacity(0.4),
                      width: 1.5,
                    ),
                  ),
                  child: const Center(
                    child: Icon(Icons.mosque, color: kGold, size: 22),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'JADWAL SHOLAT',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                      Row(
                        children: [
                          Icon(
                            Icons.location_on_rounded,
                            color: kGold.withOpacity(0.5),
                            size: 10,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            _prayerCity,
                            style: TextStyle(
                              color: Colors.white60,
                              fontSize: 10,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: _locationLoading ? null : _detectLocationAndFetchPrayer,
                  child: Container(
                    width: 36,
                    height: 36,
                    margin: const EdgeInsets.only(right: 6),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: _locationGranted
                          ? kGold.withOpacity(0.15)
                          : Colors.white.withOpacity(0.05),
                      border: Border.all(
                        color: _locationGranted
                            ? kGold.withOpacity(0.5)
                            : Colors.white.withOpacity(0.1),
                        width: 1.5,
                      ),
                    ),
                    child: _locationLoading
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(
                              color: kGold,
                              strokeWidth: 2,
                            ),
                          )
                        : Icon(
                            _locationGranted
                                ? Icons.my_location_rounded
                                : Icons.location_searching_rounded,
                            color: _locationGranted ? kGold : Colors.white54,
                            size: 16,
                          ),
                  ),
                ),
                GestureDetector(
                  onTap: _showChangeCityDialog,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [kGold, kRed],
                      ),
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: kGold.withOpacity(0.4),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: const Row(
                      children: [
                        Icon(
                          Icons.edit_location_alt_rounded,
                          color: Colors.white,
                          size: 12,
                        ),
                        SizedBox(width: 4),
                        Text(
                          'GANTI',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 9,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            if (_nextPrayerLabel.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  color: kCard,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(
                    color: kGold.withOpacity(0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  children: [
                    ScaleTransition(
                      scale: _pulseAnim,
                      child: Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: kGold,
                          boxShadow: [
                            BoxShadow(
                              color: kGold.withOpacity(0.6),
                              blurRadius: 8,
                            ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'Menuju $_nextPrayerLabel : $_nextPrayerTime',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: kGold.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: kGold.withOpacity(0.4),
                          width: 1,
                        ),
                      ),
                      child: const Text(
                        'NOW',
                        style: TextStyle(
                          color: kGold,
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 14),

            if (_prayerLoading)
              const Center(
                child: Padding(
                  padding: EdgeInsets.symmetric(vertical: 20),
                  child: CircularProgressIndicator(
                    color: kGold,
                    strokeWidth: 2,
                  ),
                ),
              )
            else
              SizedBox(
                height: 110,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  itemCount: prayerKeys.length,
                  itemBuilder: (ctx, i) {
                    final key = prayerKeys[i];
                    final time = _prayerTimes[key] ?? '--:--';
                    final color = prayerColors[i];
                    final icon = prayerIcons[i];
                    final isNext = key == _nextPrayerLabel;
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      curve: Curves.easeOut,
                      margin: EdgeInsets.only(
                        right: 8,
                        bottom: isNext ? 0 : 6,
                        top: isNext ? 0 : 6,
                      ),
                      width: 90,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: isNext
                              ? [color, color.withOpacity(0.8)]
                              : [color.withOpacity(0.6), color.withOpacity(0.3)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(14),
                        boxShadow: [
                          BoxShadow(
                            color: color.withOpacity(isNext ? 0.6 : 0.3),
                            blurRadius: isNext ? 16 : 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                        border: isNext
                            ? Border.all(
                                color: Colors.white.withOpacity(0.3),
                                width: 1.5,
                              )
                            : null,
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 6),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(icon, color: Colors.white, size: 20),
                            const SizedBox(height: 4),
                            Text(
                              key.toUpperCase(),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 8,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 0.5,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              time,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Orbitron',
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ─── HADITH SECTION ────────────────────────────────────────────────────
  Widget _buildHadithSection() {
    if (_hadithLoading) {
      return Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Container(
          height: 200,
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: kGold.withOpacity(0.3),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(
                  color: kGold,
                  strokeWidth: 2,
                ),
                SizedBox(height: 12),
                Text(
                  'Memuat Hadith...',
                  style: TextStyle(
                    color: Colors.white60,
                    fontSize: 12,
                    fontFamily: 'Orbitron',
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final arabic = _hadith?['data']?['text']?['ar'] ??
        'إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ، وَإِنَّمَا لِكُلِّ امْرِئٍ مَا نَوَى';
    final indo = _hadith?['data']?['text']?['id'] ??
        'Sesungguhnya setiap amalan tergantung pada niatnya.';
    final number = _hadith?['data']?['id']?.toString() ?? '1';
    final source = _hadith?['data']?['source']?.toString() ?? 'Muslim';
    final grade = _hadith?['data']?['grade']?.toString() ?? 'Sahih Muslim';

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: kCard,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: kGold.withOpacity(0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.3),
              blurRadius: 25,
              offset: const Offset(0, 10),
            ),
            BoxShadow(
              color: kGold.withOpacity(0.05),
              blurRadius: 30,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        kGold.withOpacity(0.2),
                        kGold.withOpacity(0.08),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: kGold.withOpacity(0.4),
                      width: 1.5,
                    ),
                  ),
                  child: const Center(
                    child: Icon(
                      Icons.menu_book_rounded,
                      color: kGold,
                      size: 22,
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'HADITH OF THE DAY',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                      Row(
                        children: [
                          Container(
                            width: 4,
                            height: 4,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: kGold,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            grade,
                            style: TextStyle(
                              color: kGold.withOpacity(0.6),
                              fontSize: 10,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                          const SizedBox(width: 6),
                          Container(
                            width: 4,
                            height: 4,
                            decoration: const BoxDecoration(
                              shape: BoxShape.circle,
                              color: Colors.white24,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'Tap card to read full',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.3),
                              fontSize: 9,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                GestureDetector(
                  onTap: _fetchRandomHadith,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: LinearGradient(
                        colors: [
                          kGold.withOpacity(0.12),
                          kGold.withOpacity(0.04),
                        ],
                      ),
                      border: Border.all(
                        color: kGold.withOpacity(0.3),
                        width: 1.5,
                      ),
                    ),
                    child: Icon(
                      Icons.refresh_rounded,
                      color: kGold.withOpacity(0.6),
                      size: 18,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 14),

            GestureDetector(
              onTap: () => _showHadithFullDialog(arabic, indo, source, number, grade),
              child: Column(
                children: [
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: kCard,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: kGold.withOpacity(0.2),
                        width: 1,
                      ),
                    ),
                    child: Text(
                      arabic,
                      textAlign: TextAlign.right,
                      textDirection: TextDirection.rtl,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 17,
                        height: 2.2,
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: kCard,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: kGold.withOpacity(0.1),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            indo,
                            style: TextStyle(
                              color: Colors.white70,
                              fontSize: 12,
                              fontStyle: FontStyle.italic,
                              height: 1.7,
                            ),
                            maxLines: 3,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        Container(
                          padding: const EdgeInsets.all(6),
                          margin: const EdgeInsets.only(left: 8),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: kGold.withOpacity(0.1),
                          ),
                          child: Icon(
                            Icons.arrow_forward_ios_rounded,
                            color: kGold.withOpacity(0.3),
                            size: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 14),

            Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                  decoration: BoxDecoration(
                    color: kCard,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                      color: kGold.withOpacity(0.2),
                      width: 1,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.receipt_long_rounded,
                        color: kGold.withOpacity(0.5),
                        size: 12,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        '${source.isNotEmpty ? source : "Muslim"} #$number',
                        style: TextStyle(
                          color: kGold.withOpacity(0.6),
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'Orbitron',
                        ),
                      ),
                    ],
                  ),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: _fetchRandomHadith,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.1),
                        width: 1,
                      ),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.touch_app_rounded,
                          color: Colors.white.withOpacity(0.3),
                          size: 12,
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'Tap ganti',
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.3),
                            fontSize: 9,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ─── CHAT MENU PAGE ────────────────────────────────────────────────────
  Widget _buildChatMenuPage() {
    final List<Map<String, dynamic>> chatMenus = [
      {
        'title': 'SPAM PAIR',
        'subtitle': 'Pairing WA & OTP TG',
        'description': 'Pairing Whatsapp dan OTP Telegram',
        'icon': FontAwesomeIcons.whatsapp,
        'gradient': [kRed, kGold],
        'badge': 'SPAM',
        'badgeColor': kRed,
        'features': ['Mudah Digunakan', 'Anti Gimmick', 'Tanpa Sender'],
        'page': SpamPairPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        ),
      },
      {
        'title': 'BUG SENDER',
        'subtitle': 'Kirim Bug WhatsApp',
        'description': 'Kirim bug dengan berbagai metode',
        'icon': FontAwesomeIcons.bug,
        'gradient': [kGold, kRed],
        'badge': 'RECOMMENDED',
        'badgeColor': kGold,
        'features': ['Mudah digunakan', 'Function terbaru', 'All work gacor'],
        'page': HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        ),
      },
      {
        'title': 'CUSTOM BUG',
        'subtitle': 'Menu custom bug',
        'description': 'Buat menu bug, delay pengiriman dan loops',
        'icon': Icons.settings_applications,
        'gradient': [kRed, kGold],
        'badge': 'CUSTOM',
        'badgeColor': kRed,
        'features': ['Pengaturan Mudah', 'Support Multi Bug', 'Bebas Spam'],
        'page': CustomPayloadPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
          listBug: listBug,
        ),
      },
      {
        'title': 'TEST FUNC',
        'subtitle': 'Custom Function',
        'description': 'Kirim function custom dengan delay & loops',
        'icon': Icons.functions_rounded,
        'gradient': [kGold, kRed],
        'badge': 'NEW',
        'badgeColor': kGold,
        'features': ['Custom Function', 'Atur Delay', 'Support Loops'],
        'page': TesFuncPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        ),
      },
    ];

    return Container(
      width: double.infinity,
      height: double.infinity,
      decoration: const BoxDecoration(
        gradient: RadialGradient(
          colors: [Color(0xFF1A1A1A), Color(0xFF0A0A0A)],
          radius: 2,
        ),
      ),
      child: Column(
        children: [
          _buildChatHeader(),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(top: 8, bottom: 16),
              child: Column(
                children: [
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: Row(
                      children: [
                        _buildQuickActionButton(
                          label: 'SPAM PAIR',
                          icon: FontAwesomeIcons.whatsapp,
                          color: kGold,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => SpamPairPage(
                                  sessionKey: sessionKey,
                                  username: username,
                                  role: role,
                                ),
                              ),
                            );
                          },
                        ),
                        SizedBox(width: 8),
                        _buildQuickActionButton(
                          label: 'BUG SENDER',
                          icon: FontAwesomeIcons.bug,
                          color: kRed,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => HomePage(
                                  username: username,
                                  password: password,
                                  listBug: listBug,
                                  role: role,
                                  expiredDate: expiredDate,
                                  sessionKey: sessionKey,
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: Row(
                      children: [
                        _buildQuickActionButton(
                          label: 'CUSTOM BUG',
                          icon: Icons.settings_applications,
                          color: kGold,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => CustomPayloadPage(
                                  sessionKey: sessionKey,
                                  username: username,
                                  role: role,
                                  listBug: listBug,
                                ),
                              ),
                            );
                          },
                        ),
                        SizedBox(width: 8),
                        _buildQuickActionButton(
                          label: 'TEST FUNC',
                          icon: Icons.functions_rounded,
                          color: kRed,
                          onTap: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => TesFuncPage(
                                  sessionKey: sessionKey,
                                  username: username,
                                  role: role,
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 8),
                  Expanded(
                    child: carousel.CarouselSlider.builder(
                      options: carousel.CarouselOptions(
                        height: double.infinity,
                        viewportFraction: 0.82,
                        initialPage: 0,
                        enableInfiniteScroll: true,
                        autoPlay: true,
                        autoPlayInterval: Duration(seconds: 4),
                        autoPlayAnimationDuration: Duration(milliseconds: 700),
                        autoPlayCurve: Curves.easeInOutCubic,
                        enlargeCenterPage: true,
                        scrollDirection: Axis.horizontal,
                        onPageChanged: (index, reason) {
                          setState(() { _carouselCurrentIndex = index; });
                        },
                      ),
                      itemCount: chatMenus.length,
                      itemBuilder: (context, index, realIndex) {
                        return _buildChatCarouselCard(chatMenus[index], index);
                      },
                    ),
                  ),
                  SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(chatMenus.length, (i) {
                      final bool active = i == _carouselCurrentIndex;
                      final Color dotColor = chatMenus[i]['badgeColor'] as Color;
                      return AnimatedContainer(
                        duration: Duration(milliseconds: 300),
                        margin: EdgeInsets.symmetric(horizontal: 4),
                        width: active ? 24 : 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: active ? dotColor : Colors.white.withOpacity(0.25),
                          borderRadius: BorderRadius.circular(4),
                          boxShadow: active
                              ? [BoxShadow(color: dotColor.withOpacity(0.6), blurRadius: 6)]
                              : [],
                        ),
                      );
                    }),
                  ),
                  SizedBox(height: 16),
                  _buildChatInfoPanel(),
                  SizedBox(height: 16),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionButton({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 10, horizontal: 8),
          decoration: BoxDecoration(
            color: kCard,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: color.withOpacity(0.6),
              width: 2,
            ),
            boxShadow: [
              BoxShadow(
                color: color.withOpacity(0.3),
                blurRadius: 10,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 16),
              SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 11,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                  letterSpacing: 0.5,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildChatHeader() {
    return Container(
      height: 175,
      width: double.infinity,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xCC1A1A1A),
            Color(0x991A1A1A),
            Colors.transparent,
          ],
          stops: [0.0, 0.6, 1.0],
        ),
      ),
      child: Stack(
        children: [
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 76,
                  height: 76,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      colors: [kGold, kRed],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: kGold.withOpacity(0.6),
                        blurRadius: 30,
                        spreadRadius: 5,
                      ),
                    ],
                    border: Border.all(color: Colors.white.withOpacity(0.3), width: 2),
                  ),
                  child: Center(
                    child: Icon(FontAwesomeIcons.whatsapp, color: Colors.white, size: 36),
                  ),
                ),
                SizedBox(height: 10),
                ShaderMask(
                  shaderCallback: (bounds) => LinearGradient(
                    colors: [Colors.white, kGold],
                  ).createShader(bounds),
                  child: Text(
                    "⚽ WORLD CUP MENU ⚽",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  "🏆 Pilih menu yang tersedia 🏆",
                  style: TextStyle(
                    color: Colors.white60,
                    fontSize: 12,
                    letterSpacing: 0.5,
                  ),
                ),
                SizedBox(height: 10),
                Container(
                  width: 100,
                  height: 2.5,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.transparent, kGold, Colors.transparent],
                    ),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChatCarouselCard(Map<String, dynamic> menu, int index) {
    final gradient = menu['gradient'] as List<Color>;
    final features = menu['features'] as List<String>;
    final Color badgeColor = menu['badgeColor'] as Color;

    return Animate(
      effects: [
        FadeEffect(duration: 350.ms, delay: (80 * index).ms),
        SlideEffect(
          begin: Offset(0, 0.04),
          end: Offset.zero,
          duration: 350.ms,
          delay: (80 * index).ms,
          curve: Curves.easeOut,
        ),
      ],
      child: GestureDetector(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => menu['page'],
            ),
          );
        },
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 6, vertical: 8),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: gradient,
            ),
            boxShadow: [
              BoxShadow(
                color: badgeColor.withOpacity(0.5),
                blurRadius: 30,
                spreadRadius: 2,
                offset: Offset(0, 12),
              ),
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 16,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(28),
            child: Stack(
              children: [
                Positioned(
                  bottom: -10,
                  right: -10,
                  child: Opacity(
                    opacity: 0.06,
                    child: Text(
                      "⚽",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 100,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(22, 20, 22, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 54,
                            height: 54,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.white.withOpacity(0.3),
                                width: 1.5,
                              ),
                            ),
                            child: Center(
                              child: Icon(
                                menu['icon'],
                                color: Colors.white,
                                size: 26,
                              ),
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: Colors.white.withOpacity(0.4),
                                width: 1.5,
                              ),
                            ),
                            child: Text(
                              menu['badge'],
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 0.8,
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 18),
                      Text(
                        menu['title'],
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 21,
                          fontWeight: FontWeight.w900,
                          letterSpacing: 0.8,
                          shadows: [Shadow(color: Colors.black45, blurRadius: 4)],
                        ),
                      ),
                      SizedBox(height: 3),
                      Text(
                        menu['subtitle'],
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.85),
                          fontSize: 12.5,
                          fontWeight: FontWeight.w400,
                          letterSpacing: 0.3,
                        ),
                      ),
                      SizedBox(height: 10),
                      Container(
                        height: 1,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.white.withOpacity(0.3),
                              Colors.white.withOpacity(0.05),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: 10),
                      Text(
                        menu['description'],
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 12.5,
                          height: 1.55,
                          letterSpacing: 0.2,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 12),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: features.take(3).map((f) => Container(
                          padding: EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: Colors.white.withOpacity(0.2)),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.check_circle_outline, color: Colors.white.withOpacity(0.9), size: 11),
                              SizedBox(width: 4),
                              Text(
                                f,
                                style: TextStyle(
                                  color: Colors.white.withOpacity(0.92),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        )).toList(),
                      ),
                      Spacer(),
                      Container(
                        margin: EdgeInsets.only(bottom: 18),
                        width: double.infinity,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.white.withOpacity(0.3), width: 1),
                        ),
                        child: Material(
                          color: Colors.transparent,
                          borderRadius: BorderRadius.circular(16),
                          child: InkWell(
                            borderRadius: BorderRadius.circular(16),
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => menu['page'],
                                ),
                              );
                            },
                            splashColor: Colors.white.withOpacity(0.2),
                            child: Padding(
                              padding: EdgeInsets.symmetric(vertical: 14),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    "START MODULE",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w800,
                                      letterSpacing: 1.2,
                                    ),
                                  ),
                                  SizedBox(width: 8),
                                  Container(
                                    width: 22,
                                    height: 22,
                                    decoration: BoxDecoration(
                                      color: Colors.white.withOpacity(0.2),
                                      shape: BoxShape.circle,
                                    ),
                                    child: Icon(Icons.arrow_forward_ios, color: Colors.white, size: 12),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildChatInfoPanel() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 20),
      padding: EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      decoration: BoxDecoration(
        color: kCard,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: kGold.withOpacity(0.3), width: 1.5),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: kGold.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.info_outline_rounded, color: kGold, size: 16),
          ),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "🏆 Semua menu telah diuji coba dan tanpa gimmick real work 100%",
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 12.5,
                    fontWeight: FontWeight.w500,
                    height: 1.4,
                  ),
                ),
                SizedBox(height: 4),
                Row(
                  children: [
                    Container(
                      width: 5, height: 5,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: kGold,
                        boxShadow: [BoxShadow(color: kGold.withOpacity(0.7), blurRadius: 5)],
                      ),
                    ),
                    SizedBox(width: 6),
                    Text(
                      "⚽ LAMBORGHINI x WORLD CUP ⚽",
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.4),
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ─── BUILD ──────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    if (_showIntro) {
      return WelcomeNoMercyIntro(
        onFinished: () => setState(() => _showIntro = false),
      );
    }

    return Scaffold(
      backgroundColor: kBg,
      extendBodyBehindAppBar: false,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Listener(
        behavior: HitTestBehavior.translucent,
        onPointerDown: _onPagePointerDown,
        onPointerUp: _onPagePointerUp,
        child: Stack(
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: RadialGradient(
                  colors: [Color(0xFF1A1A1A), Color(0xFF0A0A0A)],
                  radius: 2,
                ),
              ),
            ),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 350),
              transitionBuilder: (child, anim) =>
                  FadeTransition(opacity: anim, child: child),
              child: KeyedSubtree(
                key: ValueKey(_navIndex),
                child: _buildCurrentPage(),
              ),
            ),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: _SwipeUpHandle(
                onTap: _showNav,
                accentColor: kGold,
                lightColor: Colors.white60,
                bottomPadding: MediaQuery.of(context).padding.bottom,
              ),
            ),
            if (_isNavVisible)
              Positioned(
                left: 0,
                right: 0,
                bottom: 0,
                child: AnimatedBuilder(
                  animation: _navRevealAnimation,
                  builder: (context, child) {
                    final double t = _navRevealAnimation.value;
                    return Opacity(
                      opacity: t.clamp(0.0, 1.0),
                      child: Transform.translate(
                        offset: Offset(0, (1 - t) * 140),
                        child: child,
                      ),
                    );
                  },
                  child: _buildBottomNav(),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ─── APP BAR ────────────────────────────────────────────────────────────
  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: kCard,
      elevation: 0,
      iconTheme: const IconThemeData(color: Colors.white),
      titleSpacing: 0,
      flexibleSpace: Container(
        decoration: BoxDecoration(
          border: Border(bottom: BorderSide(color: kGold.withOpacity(0.3))),
        ),
      ),
      leading: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: kGold.withOpacity(0.2),
            border: Border.all(color: kGold.withOpacity(0.4)),
          ),
          child: const Center(
            child: Icon(Icons.sports_soccer_rounded, color: kGold, size: 18),
          ),
        ),
      ),
      title: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          const SizedBox(width: 4),
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [kGold, kRed],
            ).createShader(bounds),
            child: Text(
              '⚽ WORLD CUP ⚽',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
                letterSpacing: 2,
              ),
            ),
          ),
        ],
      ),
      centerTitle: false,
      actions: [
        GestureDetector(
          onTap: () => Navigator.push(
            context,
            _slideRoute(ProfilePage(
              username: username, password: password,
              role: role, expiredDate: expiredDate, sessionKey: sessionKey,
            )),
          ),
          child: Container(
            width: 38,
            height: 38,
            margin: const EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: kGold.withOpacity(0.6), width: 2),
              color: kGold.withOpacity(0.2),
            ),
            child: ClipOval(
              child: _profileImage != null
                  ? Image.file(_profileImage!, fit: BoxFit.cover)
                  : const Icon(Icons.person_rounded, color: kGold, size: 20),
            ),
          ),
        ),
        const SizedBox(width: 4),
        GestureDetector(
          onTap: () => Navigator.push(context, _slideRoute(const ContactPage())),
          child: const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8),
            child: Icon(Icons.headset_mic_outlined, color: Colors.white, size: 24),
          ),
        ),
        const SizedBox(width: 4),
      ],
    );
  }

  // ─── BOTTOM NAV ─────────────────────────────────────────────────────────
  Widget _buildBottomNav() {
    final items = [
      _NavItem(icon: Icons.dashboard_rounded, label: 'Dashboard'),
      _NavItem(icon: Icons.chat_rounded, label: 'Chat'),
      _NavItem(icon: Icons.people_rounded, label: 'Group'),
      _NavItem(icon: Icons.info_outline_rounded, label: 'Info'),
      _NavItem(icon: Icons.build_circle_outlined, label: 'Tools'),
    ];

    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.fromLTRB(16, 0, 16, 8 + MediaQuery.of(context).padding.bottom),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _buildNavGrabber(),
            const SizedBox(height: 8),
            Container(
              height: 78,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(30),
                color: kCard,
                border: Border.all(
                  color: kGold.withOpacity(0.4),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: kGold.withOpacity(0.2),
                    blurRadius: 30,
                    spreadRadius: 1,
                    offset: const Offset(0, 12),
                  ),
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    blurRadius: 18,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(30),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                  child: Padding(
                    padding: const EdgeInsets.all(6),
                    child: LayoutBuilder(
                      builder: (context, constraints) {
                        final double itemWidth = constraints.maxWidth / items.length;
                        return Stack(
                          children: [
                            AnimatedPositioned(
                              duration: const Duration(milliseconds: 380),
                              curve: Curves.easeOutCubic,
                              left: itemWidth * _navIndex,
                              top: 0,
                              bottom: 0,
                              width: itemWidth,
                              child: Container(
                                margin: const EdgeInsets.symmetric(horizontal: 5),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(22),
                                  gradient: LinearGradient(
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                    colors: [
                                      kGold.withOpacity(0.9),
                                      kRed.withOpacity(0.85),
                                    ],
                                  ),
                                  border: Border.all(
                                    color: Colors.white.withOpacity(0.3),
                                    width: 1.5,
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: kGold.withOpacity(0.32),
                                      blurRadius: 18,
                                      spreadRadius: 1,
                                    ),
                                    BoxShadow(
                                      color: kRed.withOpacity(0.3),
                                      blurRadius: 22,
                                      spreadRadius: 2,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Row(
                              children: List.generate(
                                items.length,
                                (index) => Expanded(
                                  child: _buildNavItem(
                                    index: index,
                                    item: items[index],
                                    isSelected: _navIndex == index,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNavItem({
    required int index,
    required _NavItem item,
    required bool isSelected,
  }) {
    bool _pressed = false;
    
    return StatefulBuilder(
      builder: (context, setState) {
        return GestureDetector(
          onTapDown: (_) => setState(() => _pressed = true),
          onTapCancel: () => setState(() => _pressed = false),
          onTapUp: (_) {
            setState(() => _pressed = false);
            _onNavTap(index);
            _scheduleNavAutoHide();
            HapticFeedback.selectionClick();
          },
          child: AnimatedScale(
            scale: _pressed ? 0.88 : (isSelected ? 1.08 : 1.0),
            duration: const Duration(milliseconds: 140),
            curve: Curves.easeOut,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 220),
                  transitionBuilder: (child, anim) {
                    return ScaleTransition(scale: anim, child: child);
                  },
                  child: Icon(
                    item.icon,
                    key: ValueKey<bool>(isSelected),
                    size: isSelected ? 26 : 22,
                    color: isSelected ? kGold : Colors.white60,
                    shadows: isSelected
                        ? [
                            Shadow(
                              color: kGold.withOpacity(0.6),
                              blurRadius: 8,
                            ),
                          ]
                        : null,
                  ),
                ),
                const SizedBox(height: 4),
                AnimatedDefaultTextStyle(
                  duration: const Duration(milliseconds: 260),
                  style: TextStyle(
                    color: isSelected ? Colors.white : Colors.white60,
                    fontSize: isSelected ? 12 : 10.5,
                    fontWeight: isSelected ? FontWeight.bold : FontWeight.w500,
                    letterSpacing: 0.3,
                  ),
                  child: Text(item.label),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // ─── DRAWER ─────────────────────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: kCard,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Column(
        children: [
          Container(
            height: 240,
            color: Colors.black,
            child: Stack(
              children: [
                if (_menuVideoCtrl != null && _menuVideoCtrl!.value.isInitialized)
                  SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _menuVideoCtrl!.value.size.width,
                        height: _menuVideoCtrl!.value.size.height,
                        child: VideoPlayer(_menuVideoCtrl!),
                      ),
                    ),
                  ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter, end: Alignment.bottomCenter,
                      colors: [Colors.black.withOpacity(0.3), Colors.black.withOpacity(0.85)],
                    ),
                  ),
                ),
                SafeArea(
                  child: Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 80, height: 80,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: kGold.withOpacity(0.8), width: 3),
                            boxShadow: [BoxShadow(color: kGold.withOpacity(0.4), blurRadius: 14, spreadRadius: 4)],
                          ),
                          child: ClipOval(
                            child: _profileImage != null
                                ? Image.file(_profileImage!, fit: BoxFit.cover)
                                : const Icon(Icons.person_rounded, size: 38, color: kGold),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(username,
                            style: const TextStyle(
                                color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Orbitron')),
                        Text(role.toUpperCase(),
                            style: const TextStyle(color: kGold, fontSize: 12, letterSpacing: 2)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: kCard,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 16),
                children: [
                  if (role == 'reseller')
                    _buildDrawerItem(
                        icon: Icons.storefront_rounded,
                        label: 'Seller Page',
                        onTap: () => _onDrawerNav(1)),
                  if (role == 'admin')
                    _buildDrawerItem(
                        icon: Icons.admin_panel_settings_rounded,
                        label: 'Admin Page',
                        onTap: () => _onDrawerNav(2)),
                  if (role == 'owner')
                    _buildDrawerItem(
                        icon: Icons.workspace_premium_rounded,
                        label: 'Owner Page',
                        onTap: () => _onDrawerNav(3)),
                  _buildDrawerItem(
                    icon: Icons.history_rounded,
                    label: 'Riwayat Aktivitas',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                          context,
                          _slideRoute(RiwayatPage(sessionKey: sessionKey, role: role))).then((_) {
                        if (mounted && _newsPageCtrl.hasClients) {
                          setState(() { _currentNewsPage = 0.0; _newsPageViewKey++; });
                          _newsPageCtrl.jumpToPage(0);
                        }
                      });
                    },
                  ),
                  _buildDrawerItem(
                    icon: Icons.lock_outline_rounded,
                    label: 'Ganti Password',
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        _slideRoute(ChangePasswordPage(username: username, sessionKey: sessionKey)),
                      );
                    },
                  ),
                  const SizedBox(height: 16),
                  _buildDrawerItem(
                    icon: Icons.logout_rounded,
                    label: 'Keluar',
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: isLogout ? Colors.red.withOpacity(0.15) : Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
            color: isLogout ? Colors.red.withOpacity(0.4) : kGold.withOpacity(0.2)),
      ),
      child: ListTile(
        leading: Icon(icon, color: isLogout ? Colors.redAccent : kGold, size: 20),
        title: Text(label,
            style: TextStyle(
                color: isLogout ? Colors.redAccent : Colors.white,
                fontWeight: FontWeight.w600, fontSize: 14)),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, color: Colors.white24, size: 13),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        onTap: onTap,
      ),
    );
  }
}

// ─── QUICK ACTION DATA ──────────────────────────────────────────────────────
class _QuickActionData {
  final IconData icon;
  final IconData bgIcon;
  final String title;
  final String subtitle;
  final List<Color> gradient;
  final VoidCallback onTap;
  const _QuickActionData({
    required this.icon,
    required this.bgIcon,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });
}

// ─── NAV ITEM ──────────────────────────────────────────────────────────────
class _NavItem {
  final IconData icon;
  final String label;
  final bool isCenter;
  const _NavItem({
    required this.icon,
    required this.label,
    this.isCenter = false,
  });
}

// ─── SLIDE ROUTE ───────────────────────────────────────────────────────────
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
  pageBuilder: (_, __, ___) => page,
  transitionDuration: const Duration(milliseconds: 350),
  transitionsBuilder: (_, anim, __, child) => SlideTransition(
    position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: anim, curve: Curves.easeOutCubic)),
    child: FadeTransition(opacity: anim, child: child),
  ),
);

// ─── SWIPE UP HANDLE ──────────────────────────────────────────────────────
class _SwipeUpHandle extends StatefulWidget {
  final VoidCallback onTap;
  final Color accentColor;
  final Color lightColor;
  final double bottomPadding;

  const _SwipeUpHandle({
    required this.onTap,
    required this.accentColor,
    required this.lightColor,
    required this.bottomPadding,
  });

  @override
  State<_SwipeUpHandle> createState() => _SwipeUpHandleState();
}

class _SwipeUpHandleState extends State<_SwipeUpHandle>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: widget.onTap,
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, _) {
          final t = _controller.value;
          final double offsetY = -3 * (0.5 + 0.5 * math.sin(t * 2 * math.pi));
          final double glowOpacity =
              0.18 + 0.22 * (0.5 + 0.5 * math.sin(t * 2 * math.pi));
          return Padding(
            padding: EdgeInsets.only(bottom: 6 + widget.bottomPadding),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Transform.translate(
                  offset: Offset(0, offsetY),
                  child: Opacity(
                    opacity: 0.7 + 0.3 * (0.5 + 0.5 * math.sin(t * 2 * math.pi)),
                    child: Icon(
                      Icons.keyboard_arrow_up_rounded,
                      color: widget.lightColor.withOpacity(0.7),
                      size: 16,
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Container(
                  width: 44,
                  height: 4,
                  decoration: BoxDecoration(
                    color: widget.lightColor.withOpacity(0.5),
                    borderRadius: BorderRadius.circular(2),
                    boxShadow: [
                      BoxShadow(
                        color: widget.accentColor.withOpacity(glowOpacity),
                        blurRadius: 12,
                        spreadRadius: 1,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}