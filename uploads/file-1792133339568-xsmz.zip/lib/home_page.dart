import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'api_config.dart';

// ─── WORLD CUP + LAMBORGHINI THEME ──────────────────────────────────────────
const Color _bgColor = Color(0xFF0A0A0A);
const Color _cardColor = Color(0xFF1A1A1A);
const Color _glassColor = Color(0xCC1A1A1A);
const Color _glassBorder = Color(0x33FFD700);
const Color _glassBorderActive = Color(0x66FFD700);
const Color _textWhite = Color(0xFFFFFFFF);
const Color _textGrey = Color(0xFFBDBDBD);
const Color _goldColor = Color(0xFFFFD700);
const Color _redColor = Color(0xFFE53935);
const Color _blackColor = Color(0xCC000000);

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  late VideoPlayerController _videoController;
  late AnimationController _pulseController;
  late AnimationController _glowController;
  late AnimationController _resultCtrl;
  late Animation<double> _resultFade;
  late Animation<Offset> _resultSlide;

  final targetController = TextEditingController();
  final PageController _bugPageController = PageController(viewportFraction: 0.85);

  String? _selectedBugId;
  bool _isSending = false;
  String? _responseMessage;
  int _currentBugPage = 0;

  List<String> _globalSenders = [];
  bool _isLoadingSenders = false;
  int _privateSenderCount = 0;
  int _globalSenderCount = 0;
  bool _loadingSender = false;
  Timer? _senderTimer;

  String _selectedSender = 'private';

  Map<String, AnimationController> _bugAnimations = {};
  Map<String, double> _bugOffsets = {};

  bool get canAccessGlobalSender {
    final r = widget.role.toLowerCase();
    return r == 'owner' ||
        r == 'admin' ||
        r == 'moderator' ||
        r == 'partner' ||
        r == 'vip';
  }

  @override
  void initState() {
    super.initState();

    _videoController = VideoPlayerController.asset('assets/videos/background.mp4')
      ..initialize().then((_) {
        if (!mounted) return;
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(100);
        _videoController.play();
      });

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _glowController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _resultCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 450));
    _resultFade = CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOut);
    _resultSlide = Tween<Offset>(begin: const Offset(0, 0.12), end: Offset.zero)
        .animate(CurvedAnimation(parent: _resultCtrl, curve: Curves.easeOutCubic));

    _fetchSenderStats();
    _loadGlobalSenders();
    _senderTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      _fetchSenderStats();
    });

    if (widget.listBug.isNotEmpty) {
      final firstBug = widget.listBug[0];
      _selectedBugId = firstBug['bug_id'] as String? ?? '0';
    }

    for (var bug in widget.listBug) {
      final bugId = bug['bug_id'] as String? ?? '0';
      final controller = AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 500),
      );
      _bugAnimations[bugId] = controller;
      _bugOffsets[bugId] = 0.0;
      
      controller.addListener(() {
        setState(() {
          _bugOffsets[bugId] = controller.value;
        });
      });
    }
  }

  @override
  void dispose() {
    _videoController.dispose();
    _pulseController.dispose();
    _glowController.dispose();
    _resultCtrl.dispose();
    targetController.dispose();
    _bugPageController.dispose();
    _senderTimer?.cancel();
    for (var controller in _bugAnimations.values) {
      controller.dispose();
    }
    super.dispose();
  }

  Future<void> _fetchSenderStats() async {
    if (_loadingSender) return;
    setState(() => _loadingSender = true);
    try {
      final response = await http.get(
        Uri.parse("http://zyroback.pterocloud.my.id:10847/getSenderStats?key=${widget.sessionKey}"),
      ).timeout(const Duration(seconds: 10));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            _privateSenderCount = data['private'] ?? 0;
            _globalSenderCount = data['global'] ?? 0;
            _loadingSender = false;
          });
        } else {
          setState(() => _loadingSender = false);
        }
      } else {
        setState(() => _loadingSender = false);
      }
    } catch (_) {
      setState(() => _loadingSender = false);
    }
  }

  Future<void> _loadGlobalSenders() async {
    setState(() => _isLoadingSenders = true);
    try {
      final res = await http.get(Uri.parse(
        'http://zyroback.pterocloud.my.id:10847/getActiveSenders?key=${widget.sessionKey}',
      )).timeout(const Duration(seconds: 10));
      final data = jsonDecode(res.body);
      if (data['valid'] == true && data['senders'] != null) {
        if (mounted) {
          setState(() {
            _globalSenders = List<String>.from(data['senders']);
            _globalSenderCount = _globalSenders.length;
          });
        }
      } else {
        if (mounted) setState(() => _globalSenders = []);
      }
    } catch (_) {
      if (mounted) setState(() => _globalSenders = []);
    } finally {
      if (mounted) setState(() => _isLoadingSenders = false);
    }
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  void _setResponse(String type, String msg) {
    if (!mounted) return;
    setState(() => _responseMessage = '$type|$msg');
    _resultCtrl.forward(from: 0);
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final key = widget.sessionKey;

    if (formatPhoneNumber(rawInput) == null) {
      _showAlert("⚽ Nomor Tidak Valid",
          "Gunakan format internasional.\nContoh: +62812xxxxxxxx");
      return;
    }

    if (_selectedSender == 'global' && !canAccessGlobalSender) {
      _showAlert("⛔ Akses Ditolak",
          "Sender Global hanya untuk Owner, Admin, Moderator, Partner & VIP!");
      return;
    }

    if (_selectedBugId == null || _selectedBugId!.isEmpty) {
      _showAlert("⚽ No Bug Selected", "Pilih 1 bug untuk dikirim.");
      return;
    }

    if (_selectedSender == 'private' && _privateSenderCount == 0) {
      _showAlert("⚽ No Private Sender", "Tidak ada private sender tersedia.");
      return;
    }
    if (_selectedSender == 'global' && _globalSenderCount == 0) {
      _showAlert("⚽ No Global Sender", "Tidak ada global sender tersedia.");
      return;
    }

    setState(() {
      _isSending = true;
      _responseMessage = null;
    });
    _resultCtrl.reset();

    try {
      final encodedTarget = Uri.encodeComponent(rawInput);
      final res = await http.get(Uri.parse(
        'http://zyroback.pterocloud.my.id:10847/sendBug'
        '?key=$key'
        '&target=$encodedTarget'
        '&bug=${_selectedBugId}'
        '${_selectedSender == 'global' ? '&senderMode=global' : '&sender=private'}',
      )).timeout(const Duration(seconds: 15));
      final data = jsonDecode(res.body);

      if (data['valid'] == false) {
        _setResponse('error', 'Session key tidak valid. Silakan login ulang.');
      } else if (data['cooldown'] == true) {
        final wait = data['wait'] ?? 0;
        _setResponse('warning', 'Cooldown aktif! Tunggu $wait detik lagi.');
      } else if (data['sended'] == true) {
        final role = data['role'] ?? widget.role;
        _setResponse('success', '🏆 Bug berhasil dikirim ke $rawInput! [$role]');
        targetController.clear();
      } else {
        _setResponse('error', 'Gagal mengirim. Server sedang maintenance.');
      }
    } on Exception catch (e) {
      if (e.toString().contains('TimeoutException')) {
        _setResponse('error', 'Request timeout. Periksa koneksi internet.');
      } else {
        _setResponse('error', 'Koneksi error. Periksa jaringan dan coba lagi.');
      }
    } finally {
      if (mounted) setState(() => _isSending = false);
    }
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: AlertDialog(
          backgroundColor: _glassColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: _goldColor.withOpacity(0.5), width: 1.5),
          ),
          title: Text(title,
              style: TextStyle(
                  color: _textWhite,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold)),
          content: Text(msg, style: TextStyle(color: _textGrey)),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK",
                  style: TextStyle(
                      color: _goldColor, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _glassCard({
    required Widget child,
    EdgeInsets padding = const EdgeInsets.all(16),
    BorderRadius? borderRadius,
    Color? borderColor,
    double blurSigma = 12,
    Color? bgColor,
  }) {
    return ClipRRect(
      borderRadius: borderRadius ?? BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blurSigma, sigmaY: blurSigma),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: bgColor ?? _glassColor,
            borderRadius: borderRadius ?? BorderRadius.circular(20),
            border: Border.all(
              color: borderColor ?? _glassBorder,
              width: 1.2,
            ),
          ),
          child: child,
        ),
      ),
    );
  }

  // ─── TOP APP BAR ──────────────────────────────────────────────────────────
  Widget _buildTopAppBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: _goldColor.withOpacity(0.2),
              border: Border.all(color: _goldColor.withOpacity(0.5), width: 1.5),
            ),
            child: const Icon(Icons.sports_soccer_rounded, color: _goldColor, size: 20),
          ),
          const SizedBox(width: 10),
          ShaderMask(
            shaderCallback: (bounds) => const LinearGradient(
              colors: [_goldColor, _redColor],
            ).createShader(bounds),
            child: Text(
              '⚽ WORLD CUP ⚽',
              style: TextStyle(
                color: _textWhite,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w900,
                fontSize: 18,
                letterSpacing: 2,
              ),
            ),
          ),
          const Spacer(),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: _goldColor.withOpacity(0.5), width: 1.5),
              color: _goldColor.withOpacity(0.1),
            ),
            child: Text(
              '🏆 WC',
              style: TextStyle(
                color: _goldColor,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                fontSize: 12,
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── HEADER ───────────────────────────────────────────────────────────────
  Widget _buildHeader() {
    return _glassCard(
      borderColor: _goldColor.withOpacity(0.3),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: _goldColor.withOpacity(0.6), width: 2.5),
                  boxShadow: [
                    BoxShadow(
                      color: _goldColor.withOpacity(0.3),
                      blurRadius: 15,
                    ),
                  ],
                ),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/logo.png',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        Icon(Icons.person, color: _goldColor, size: 32),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.username.toUpperCase(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 18,
                        letterSpacing: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(
                        color: _goldColor.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _goldColor.withOpacity(0.3)),
                      ),
                      child: Text(
                        widget.role.toUpperCase(),
                        style: TextStyle(
                          color: _goldColor,
                          fontFamily: 'ShareTechMono',
                          fontWeight: FontWeight.bold,
                          fontSize: 12,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: _glassColor,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _goldColor.withOpacity(0.3)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.access_time_rounded, color: _textGrey, size: 13),
                    const SizedBox(width: 5),
                    Text(
                      widget.expiredDate,
                      style: TextStyle(
                        color: _textWhite,
                        fontFamily: 'ShareTechMono',
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
            decoration: BoxDecoration(
              color: _blackColor,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: _goldColor.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                _buildStatItem(
                  Icons.bug_report_rounded, 
                  _goldColor,
                  '${widget.listBug.length}', 
                  'Total Bugs'
                ),
                _buildStatDivider(),
                _buildStatItem(
                  Icons.bolt_rounded, 
                  _redColor,
                  '🏆', 
                  'World Cup'
                ),
                _buildStatDivider(),
                _buildStatItem(
                  Icons.check_circle_rounded, 
                  _goldColor,
                  '⚽', 
                  'Active'
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(IconData icon, Color color, String value, String label) {
    return Expanded(
      child: Column(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color.withOpacity(0.2),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          const SizedBox(height: 5),
          Text(value,
              style: TextStyle(
                  color: _textWhite,
                  fontWeight: FontWeight.w900,
                  fontSize: 12,
                  fontFamily: 'Orbitron')),
          const SizedBox(height: 1),
          Text(label,
              style: TextStyle(
                  color: _textGrey, fontSize: 9, fontFamily: 'ShareTechMono')),
        ],
      ),
    );
  }

  Widget _buildStatDivider() {
    return Container(width: 1, height: 52, color: _goldColor.withOpacity(0.2));
  }

  // ─── NOMOR TARGET + PILIH BUG ──────────────────────────────────────────
  Widget _buildNomorDanBugPanel() {
    return _glassCard(
      borderColor: _goldColor.withOpacity(0.3),
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.phone_android_rounded, color: _goldColor, size: 18),
              const SizedBox(width: 8),
              Text(
                '🏁 NOMOR TARGET',
                style: TextStyle(
                  color: _textWhite,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),

          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
              child: Container(
                decoration: BoxDecoration(
                  color: _glassColor,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _goldColor.withOpacity(0.3), width: 1),
                ),
                child: TextField(
                  controller: targetController,
                  style: TextStyle(color: _textWhite, fontFamily: 'ShareTechMono', fontSize: 15),
                  cursorColor: _goldColor,
                  keyboardType: TextInputType.phone,
                  decoration: InputDecoration(
                    hintText: '62xxxxxxxxxx',
                    hintStyle: TextStyle(color: _textGrey.withOpacity(0.5), fontFamily: 'ShareTechMono'),
                    prefixIcon: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      child: Icon(Icons.language_rounded, color: _goldColor, size: 20),
                    ),
                    prefixIconConstraints: const BoxConstraints(minWidth: 50, minHeight: 50),
                    border: InputBorder.none,
                    contentPadding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),

          Row(
            children: [
              Icon(Icons.bug_report, color: _goldColor, size: 20),
              const SizedBox(width: 8),
              Text(
                '⚽ PILIH BUG',
                style: TextStyle(
                  color: _textWhite,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          SizedBox(
            height: 130,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: widget.listBug.length,
              physics: const BouncingScrollPhysics(),
              itemBuilder: (context, index) {
                final bug = widget.listBug[index];
                final bugId = bug['bug_id'] as String? ?? '$index';
                final bugName = bug['bug_name'] as String? ?? 'BUG';
                final isSelected = _selectedBugId == bugId;

                final offsetY = _bugOffsets[bugId] ?? 0.0;

                return Padding(
                  padding: EdgeInsets.only(
                    right: 12,
                    left: index == 0 ? 0 : 0,
                  ),
                  child: GestureDetector(
                    onTap: () {
                      final controller = _bugAnimations[bugId];
                      if (controller != null) {
                        controller.forward(from: 0).then((_) {
                          controller.reverse();
                        });
                      }
                      
                      setState(() {
                        _selectedBugId = bugId;
                      });
                    },
                    child: Transform.translate(
                      offset: Offset(0, -offsetY * 20),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(16),
                        child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 250),
                            width: 200,
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                            decoration: BoxDecoration(
                              color: isSelected 
                                  ? _goldColor.withOpacity(0.3)
                                  : _goldColor.withOpacity(0.08),
                              borderRadius: BorderRadius.circular(16),
                              border: Border.all(
                                color: isSelected 
                                    ? _goldColor 
                                    : _goldColor.withOpacity(0.3),
                                width: isSelected ? 2 : 1.2,
                              ),
                              boxShadow: isSelected ? [
                                BoxShadow(
                                  color: _goldColor.withOpacity(0.4), 
                                  blurRadius: 25, 
                                  spreadRadius: 3
                                )
                              ] : [],
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  isSelected ? Icons.flag_rounded : Icons.shield_rounded,
                                  color: isSelected ? _goldColor : _textGrey,
                                  size: 28,
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        bugName,
                                        style: TextStyle(
                                          color: isSelected ? _textWhite : _textGrey,
                                          fontFamily: 'Orbitron',
                                          fontWeight: FontWeight.bold,
                                          fontSize: 13,
                                          letterSpacing: 0.5,
                                        ),
                                        overflow: TextOverflow.visible,
                                        maxLines: 1,
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        '🏆 ${bugId.toLowerCase()}',
                                        style: TextStyle(
                                          color: isSelected 
                                              ? _goldColor
                                              : _textGrey,
                                          fontFamily: 'ShareTechMono',
                                          fontSize: 11,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                if (isSelected)
                                  Icon(
                                    Icons.check_circle,
                                    color: _goldColor,
                                    size: 22,
                                  ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 10),

          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(widget.listBug.length, (i) {
              final bug = widget.listBug[i];
              final bugId = bug['bug_id'] as String? ?? '$i';
              final isActive = _selectedBugId == bugId;
              return AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.symmetric(horizontal: 2),
                width: isActive ? 18 : 6,
                height: 4,
                decoration: BoxDecoration(
                  color: isActive ? _goldColor : _glassBorder,
                  borderRadius: BorderRadius.circular(2),
                ),
              );
            }),
          ),
        ],
      ),
    );
  }

  // ─── SENDER PANEL ────────────────────────────────────────────────────────
  Widget _buildSenderPanel() {
    return _glassCard(
      borderColor: _goldColor.withOpacity(0.3),
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.swap_horiz_rounded, color: _goldColor, size: 18),
              const SizedBox(width: 6),
              Text(
                '🏆 PILIH SENDER',
                style: TextStyle(
                  color: _textWhite,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              GestureDetector(
                onTap: () {
                  _fetchSenderStats();
                  _loadGlobalSenders();
                },
                child: Container(
                  width: 26,
                  height: 26,
                  decoration: BoxDecoration(
                    color: _glassColor,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: _goldColor.withOpacity(0.3)),
                  ),
                  child: (_isLoadingSenders || _loadingSender)
                      ? Padding(
                          padding: const EdgeInsets.all(5),
                          child: CircularProgressIndicator(
                              strokeWidth: 1.5, color: _goldColor),
                      )
                      : Icon(Icons.refresh_rounded, color: _goldColor, size: 14),
                ),
              ),
              const SizedBox(width: 6),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: _goldColor.withOpacity(0.5)),
                  color: _goldColor.withOpacity(0.1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: _goldColor,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      _loadingSender
                          ? '-- sender online'
                          : '${_privateSenderCount + _globalSenderCount} sender online',
                      style: TextStyle(
                          color: _textWhite,
                          fontFamily: 'ShareTechMono',
                          fontSize: 9),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          Row(
            children: [
              Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _selectedSender = 'private'),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: 120,
                    decoration: BoxDecoration(
                      color: _selectedSender == 'private'
                          ? _goldColor.withOpacity(0.15)
                          : _glassColor,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: _selectedSender == 'private'
                            ? _goldColor
                            : _glassBorder,
                        width: 1.5,
                      ),
                      boxShadow: _selectedSender == 'private'
                          ? [
                              BoxShadow(
                                color: _goldColor.withOpacity(0.2),
                                blurRadius: 20,
                                spreadRadius: 2,
                              )
                            ]
                          : [],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.person_rounded,
                          color: _selectedSender == 'private'
                              ? _goldColor
                              : _textGrey,
                          size: 30,
                        ),
                        const SizedBox(height: 6),
                        Text(
                          'Pribadi',
                          style: TextStyle(
                            color: _selectedSender == 'private'
                                ? _goldColor
                                : _textGrey,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.bold,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(height: 4),
                        _privateSenderCount == 0
                            ? Text(
                                '✕ Kosong',
                                style: TextStyle(
                                  color: _selectedSender == 'private'
                                      ? Colors.white54
                                      : Colors.redAccent,
                                  fontFamily: 'ShareTechMono',
                                  fontWeight: FontWeight.bold,
                                  fontSize: 10,
                                ),
                              )
                            : Text(
                                '$_privateSenderCount sender',
                                style: TextStyle(
                                  color: _selectedSender == 'private'
                                      ? _goldColor
                                      : _textWhite,
                                  fontFamily: 'ShareTechMono',
                                  fontSize: 10,
                                ),
                              ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),

              Expanded(
                child: GestureDetector(
                  onTap: () {
                    if (!canAccessGlobalSender) {
                      _showAlert('⛔ Akses Ditolak',
                          'Sender Global hanya untuk Owner, Admin, Moderator, Partner & VIP!');
                      return;
                    }
                    setState(() => _selectedSender = 'global');
                    _loadGlobalSenders();
                  },
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    height: 120,
                    decoration: BoxDecoration(
                      color: _selectedSender == 'global'
                          ? _goldColor.withOpacity(0.15)
                          : _glassColor,
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: _selectedSender == 'global'
                            ? _goldColor
                            : _glassBorder,
                        width: 1.5,
                      ),
                      boxShadow: _selectedSender == 'global'
                          ? [
                              BoxShadow(
                                color: _goldColor.withOpacity(0.2),
                                blurRadius: 20,
                                spreadRadius: 2,
                              )
                            ]
                          : [],
                    ),
                    child: Stack(
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const SizedBox(width: double.infinity),
                            Icon(
                              Icons.public_rounded,
                              color: _selectedSender == 'global'
                                  ? _goldColor
                                  : _textGrey,
                              size: 30,
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'Global',
                              style: TextStyle(
                                color: _selectedSender == 'global'
                                    ? _goldColor
                                    : _textGrey,
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.bold,
                                fontSize: 12,
                              ),
                            ),
                            const SizedBox(height: 4),
                            _globalSenderCount == 0
                                ? Text(
                                    '✕ Kosong',
                                    style: TextStyle(
                                      color: _selectedSender == 'global'
                                          ? Colors.white54
                                          : Colors.redAccent,
                                      fontFamily: 'ShareTechMono',
                                      fontWeight: FontWeight.bold,
                                      fontSize: 10,
                                    ),
                                  )
                                : Text(
                                    '$_globalSenderCount sender',
                                    style: TextStyle(
                                      color: _selectedSender == 'global'
                                          ? _goldColor
                                          : _textWhite,
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 10,
                                    ),
                                  ),
                          ],
                        ),
                        if (!canAccessGlobalSender)
                          Positioned(
                            top: 6,
                            right: 6,
                            child: Container(
                              width: 18,
                              height: 18,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: _goldColor,
                                border: Border.all(
                                    color: Colors.black26, width: 1.2),
                              ),
                              child: const Icon(Icons.lock_rounded,
                                  color: Colors.white, size: 10),
                            ),
                          ),
                        if (_selectedSender == 'global' && _globalSenderCount > 0)
                          Positioned(
                            top: 6,
                            right: 6,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: _goldColor,
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                '⚽',
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                  fontFamily: 'Orbitron',
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),

          if (_selectedSender == 'global' && _globalSenders.isNotEmpty)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _glassColor,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _goldColor.withOpacity(0.3)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Icon(Icons.format_list_bulleted_rounded,
                        color: _goldColor, size: 13),
                    const SizedBox(width: 6),
                    Text('${_globalSenders.length} sender aktif',
                        style: TextStyle(
                            color: _textGrey,
                            fontSize: 11,
                            fontFamily: 'ShareTechMono',
                            fontWeight: FontWeight.w600)),
                  ]),
                  const SizedBox(height: 8),
                  ...(_globalSenders.take(5).map((s) => Padding(
                        padding: const EdgeInsets.only(bottom: 4),
                        child: Row(children: [
                          Container(
                              width: 5,
                              height: 5,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: _goldColor)),
                          const SizedBox(width: 8),
                          Text(s,
                              style: TextStyle(
                                  color: _textWhite,
                                  fontSize: 11,
                                  fontFamily: 'ShareTechMono')),
                        ]),
                      ))),
                  if (_globalSenders.length > 5)
                    Text('+ ${_globalSenders.length - 5} lainnya...',
                        style: TextStyle(color: _textGrey, fontSize: 10)),
                ],
              ),
            )
          else
            Row(
              children: [
                Icon(Icons.info_outline_rounded, color: _goldColor, size: 13),
                const SizedBox(width: 6),
                Text(
                  '🏆 Sender global: unlimited',
                  style: TextStyle(
                      color: _goldColor,
                      fontFamily: 'ShareTechMono',
                      fontSize: 11,
                      fontWeight: FontWeight.w600),
                ),
              ],
            ),
        ],
      ),
    );
  }

  // ─── SEND BUTTON ─────────────────────────────────────────────────────────
  Widget _buildSendButton() {
    return AnimatedBuilder(
      animation: _pulseController,
      builder: (context, child) {
        return Container(
          height: 54,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              colors: [
                _redColor,
                _goldColor,
              ],
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
            ),
            boxShadow: [
              BoxShadow(
                color: _goldColor.withOpacity(0.3 + _pulseController.value * 0.2),
                blurRadius: 20 + _pulseController.value * 10,
                spreadRadius: 1,
              ),
            ],
            border: Border.all(
              color: _goldColor.withOpacity(0.5),
              width: 1.5,
            ),
          ),
          child: ElevatedButton(
            onPressed: _isSending ? null : _sendBug,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
              elevation: 0,
            ),
            child: _isSending
                ? SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(
                        color: _textWhite, strokeWidth: 2.5))
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.rocket_launch_rounded,
                          color: _textWhite, size: 18),
                      const SizedBox(width: 8),
                      const Text(
                        '🏆 KIRIM BUG 🏆',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 14,
                          fontFamily: 'Orbitron',
                          letterSpacing: 1.5,
                        ),
                      ),
                    ],
                  ),
          ),
        );
      },
    );
  }

  // ─── RESPONSE MESSAGE ────────────────────────────────────────────────────
  Widget _buildResponseMessage() {
    if (_responseMessage == null) return const SizedBox.shrink();

    final parts = _responseMessage!.split('|');
    final type = parts[0];
    final msg = parts.length > 1 ? parts[1] : '';

    Color color;
    IconData icon;
    String title;
    switch (type) {
      case 'success':
        color = _goldColor;
        icon = Icons.check_circle_outline;
        title = '🏆 Berhasil';
        break;
      case 'warning':
        color = Colors.amberAccent;
        icon = Icons.warning_rounded;
        title = '⚠️ Peringatan';
        break;
      default:
        color = _redColor;
        icon = Icons.error_outline;
        title = '❌ Gagal';
    }

    return FadeTransition(
      opacity: _resultFade,
      child: SlideTransition(
        position: _resultSlide,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              margin: const EdgeInsets.only(top: 12),
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              decoration: BoxDecoration(
                color: _glassColor,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _goldColor.withOpacity(0.5)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: color.withOpacity(0.12)),
                    child: Icon(icon, color: color, size: 18),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title,
                            style: TextStyle(
                                color: color,
                                fontFamily: 'Orbitron',
                                fontSize: 13,
                                fontWeight: FontWeight.bold)),
                        const SizedBox(height: 3),
                        Text(msg,
                            style: TextStyle(
                                color: _textGrey,
                                fontFamily: 'ShareTechMono',
                                fontSize: 12,
                                height: 1.4)),
                      ],
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      setState(() => _responseMessage = null);
                      _resultCtrl.reset();
                    },
                    child: Icon(Icons.close_rounded, color: _textGrey, size: 16),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ─── BUILD ──────────────────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          SizedBox(
            width: double.infinity,
            height: double.infinity,
            child: _videoController.value.isInitialized
                ? VideoPlayer(_videoController)
                : Container(color: Colors.black),
          ),

          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.black.withOpacity(0.2),
                  Colors.black.withOpacity(0.6),
                ],
              ),
            ),
          ),

          SafeArea(
            child: Column(
              children: [
                _buildTopAppBar(),
                Container(height: 1, color: _goldColor.withOpacity(0.2)),
                Expanded(
                  child: SingleChildScrollView(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _buildHeader(),
                        const SizedBox(height: 14),
                        _buildNomorDanBugPanel(),
                        const SizedBox(height: 14),
                        _buildSenderPanel(),
                        const SizedBox(height: 20),
                        _buildSendButton(),
                        _buildResponseMessage(),
                        const SizedBox(height: 24),
                        Center(
                          child: Text(
                            '⚽ LAMBORGHINI x WORLD CUP ⚽',
                            style: TextStyle(
                              color: _goldColor.withOpacity(0.2),
                              fontSize: 11,
                              fontFamily: 'Orbitron',
                              letterSpacing: 2,
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}